<!DOCTYPE html>
<html lang="ja">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>卒業生の方へ | 東京工学院専門学校 / 東京エアトラベル・ホテル専門学校</title>
    <meta name="keywords" content="卒業生の方へ総合学院テクノスカレッジ,東京工学院専門学校,東京エアトラベル・ホテル専門学校" />
    <meta name="description" content="" />
    <meta name="format-detection" content="telephone=no">
    <link rel="canonical" href="" />
    <link rel="shortcut icon" type="image/x-icon" href="/lib/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

<script type="text/javascript" src="//www2.infoclipper.net/infohp_js/751c6lf.js" charset="UTF-8"></script>
<script type="text/javascript" src="//www2.infoclipper.net/infohp_js/fpAnalysis.js" charset="UTF-8"></script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NF9PB6Z');</script>
<!-- End Google Tag Manager -->
    <!--CSS File-->
    <link rel="stylesheet" type="text/css" href="/new/css/reset.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/common.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/new/css/pc_style.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/sp_style.css" media="screen,print">

    <!--TOP CSS-->
<link rel="stylesheet" type="text/css" href="/new/css/forobog/pc_style.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/forobog/sp_style.css" media="screen,print">

    
    

    <!--JS File-->
    <script type="text/javascript" src="/new/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/new/js/jquery.matchHeight.js"></script>
    <script type="text/javascript" src="/new/js/jquery.inview.js"></script>
<script type="text/javascript" src="/new/js/custom.js"></script>
<script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script>

    <!--<script type="text/javascript" src="/new/js/jquery.bxslider.min.js"></script>-->

    
    
    
<script type="text/javascript" src="/lib/js/ga.js"></script>
</head>
<body >
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NF9PB6Z"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="fakeLoader"></div>
<div class="wrapper">
    

    <!--/header-->
    <header>
        <div class="inner cf onlyPC">
            <div class="h1_box">
                <a href="/"><h1>総合学院テクノスカレッジ</h1>
            <img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a>    
            </div>
        
            <nav>
            <!--<a href="/admission/" class="bnr"><img src="/new/img/header_bnr_college.png" alt="まだ間に合う！大学コース"></a>-->
                <div class="sns">
                <a href="/experience/" class="oc_btn_head">オープンキャンパス</a>
                    <ul>
                        <li><a href="https://technosac.jp/weblog/" target="_blank">テクノスブログ</a></li>
                    </ul>
                </div>


                <div class="main_menu">
                    <ul class="mainlist">
                        <li><a href="/eng/">東京工学院専門学校</a></li>
                        <li><a href="/air/">東京エアトラベル・ホテル<br />専門学校</a></li>
                        <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1" target="_blank">資料請求</a></li>
                        <li><a href="/access.php">アクセス</a></li>
                        <li><a class="menu_btn"><span class="menu_btn-icon"></span>MENU</a></li>
                    </ul>

                    <div class="nav_inner cf">
                        <dl class="menulist">
                            <dt><a href="/admission/">入学のご案内</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/admission/">募集要項・学費・奨学金</a></li>
                                    <li><a href="/admission/admission.php">入学までの流れ</a></li>
                                    <li><a href="/admission/selection.php">選考方法</a></li>
                                    <li><a href="/admission/ao.php">AO入学</a></li>
                                    <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker01">各種奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
                                    <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <dl class="menulist">
                            <dt><a href="/school/">学院案内／教育理念</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/school/greetings.php#unker02">理事長挨拶</a></li>
                                    <li><a href="/school/greetings.php#unker01">建学の精神</a></li>
                                    <li><a href="/school/greetings.php#unker04">沿革</a></li>
                                    <li><a href="/school/greetings.php#unker03">学院長挨拶</a></li>
                                <li><a href="/school/greetings.php/#unker05">情報公開</a></li>
                                </ul>
                            </dd>
                            <dt><a href="/campus/">キャンパスライフ</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/campus/facilities.php">施設紹介</a></li>
                                    <li><a href="/campus/club.php">部活・クラブ紹介</a></li>
                                    <li><a href="/campus/internationalweek.php">インターナショナルウィーク</a></li>
                                    <li><a href="/campus/twinneduniv.php">海外姉妹校の紹介</a></li>
                                <li><a href="/campus/sandwich-study-abroad.php">サンドイッチ留学</a></li>
                                    <li><a href="/campus/eng-year-event.php">東京工学院専門学校 年間イベント</a></li>
                                    <li><a href="/campus/air-year-event.php">東京エアトラベル・ホテル専門学校 年間イベント</a></li>
                                </ul>
                            </dd>
                            <dt>就職への取り組み</dt>
                            <dd>
                                <ul>
                                    <li><a href="/manabi/career.php">キャリア支援プログラム</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <ul class="link_list">
                            <li><a href="/eng/">東京工学院専門学校</a></li>
                            <li><a href="/air/">東京エアトラベル・ホテル専門学校</a></li>
                        <li><a href="/manabi/prag.php">PRAGについて</a></li>
                        <li><a href="/manabi/seminar.php">TECHNOS ゼミについて</a></li>
                            <li><a href="/school/collagecourse.php">大学コース</a></li>
                            <li><a href="/experience/">オープンキャンパス</a></li>
                            <li><a href="/access.php">アクセス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1">資料請求</a></li>
                            <li><a href="/forobog.php">卒業生の皆さまへ</a></li>
                            <li><a href="/school/parent.php">保護者の皆さまへ</a></li>
                            <li><a href="/carriercanter/carriercanter.php">企業の皆さまへ</a></li>
                            <li><a href="/inquiry.php">お問い合わせ</a></li>
                            <li><a href="/faq.php">Q&amp;A</a></li>
                        <li class="middle"><a href="https://technosac.jp/weblog/" target="_blank">テクノスブログ</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

        <div class="onlySP">
            <ul class="main_nav cf">
                <li><a href="/"><img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a></li>
                <li><a href="/eng/"><img src="/new/img/sp_menu01.png" alt="東京工学院専門学校"></a></li>
                <li><a href="/air/"><img src="/new/img/sp_menu02.png" alt="東京エアトラベル・ホテル専門学校"></a></li>
                <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1"><img src="/new/img/sp_menu03.png" alt="資料請求"></a></li>
                <li><a href="/access.php"><img src="/new/img/sp_menu04.png" alt="アクセス"></a></li>
                <li><a class="menu_btn"><span class="menu_btn-icon"></span><p>MENU</p></a></li>
            </ul>

            <div class="nav_inner cf">
                <div class="sns">
                    <ul>
                        <li class="blog"><a href="/weblog/" target="_blank"><img src="/new/img/head_blog_sp.png" alt="BLOG">テクノスブログ</a></li>
                        <!--<li><a href="" target="_blank"><img src="/new/img/head_twitter_sp.png" alt="Twitter"></a></li>
                        <li><a href="" target="_blank"><img src="/new/img/head_fb_sp.png" alt="Facebook"></a></li>
                        <li><a href="" target="_blank"><img src="/new/img/head_line_sp.png" alt="LINE@"></a></li>-->
                    </ul>
                </div>

                        <dl class="menulist">
                            <dt class="acc"><a href="/admission/">入学のご案内</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/admission/">募集要項・学費・奨学金</a></li>
                                    <li><a href="/admission/admission.php">入学までの流れ</a></li>
                                    <li><a href="/admission/selection.php">選考方法</a></li>
                                    <li><a href="/admission/ao.php">AO入学</a></li>
                                    <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker01">各種奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
                                    <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <dl class="menulist">
                            <dt class="acc"><a href="/school/">学院案内／教育理念</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/school/greetings.php#unker02">理事長挨拶</a></li>
                                    <li><a href="/school/greetings.php#unker01">建学の精神</a></li>
                                    <li><a href="/school/greetings.php#unker04">沿革</a></li>
                                    <li><a href="/school/greetings.php#unker03">学院長挨拶</a></li>
                                <li><a href="/school/greetings.php/#unker05">情報公開</a></li>
                                </ul>
                            </dd>
                            <dt class="acc"><a href="/campus/">キャンパスライフ</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/campus/facilities.php">施設紹介</a></li>
                                    <li><a href="/campus/club.php">部活・クラブ紹介</a></li>
                                    <li><a href="/campus/internationalweek.php">インターナショナルウィーク</a></li>
                                    <li><a href="/campus/twinneduniv.php">海外姉妹校の紹介</a></li>
                                <li><a href="/campus/sandwich-study-abroad.php">サンドイッチ留学</a></li>
                                    <li><a href="/campus/eng-year-event.php">東京工学院専門学校 年間イベント</a></li>
                                    <li><a href="/campus/air-year-event.php">東京エアトラベル・ホテル専門学校 年間イベント</a></li>
                                </ul>
                            </dd>
                            <dt class="acc">就職への取り組み</dt>
                            <dd>
                                <ul>
                                    <li><a href="/manabi/career.php">キャリア支援プログラム</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <ul class="link_list">
                            <li><a href="/eng/">東京工学院専門学校</a></li>
                            <li><a href="/air/">東京エアトラベル・ホテル専門学校</a></li>
                        <li><a href="/manabi/prag.php">PRAGについて</a></li>
                        <li><a href="/manabi/seminar.php">TECHNOS ゼミについて</a></li>
                            <li><a href="/school/collagecourse.php">大学コース</a></li>
                            <li><a href="/experience/">オープンキャンパス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=5&fsno=1&openExternalBrowser=1" target="_blank">オープンキャンパスのお申し込みはこちら</a></li>
                            <!-- <li><a href="https://technosac.jp/entry/tour.php">学校見学</a></li> -->
                            <li><a href="/experience/">イベント</a></li>
                        <!--
                            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">入学説明会</a></li>
                            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">保護者説明会</a></li>
                            <li><a href="/experience/#daigaku_course">大学コース説明</a></li>
                        -->
                            <li><a href="/access.php">アクセス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1">資料請求</a></li>
                            <li><a href="/forobog.php">卒業生の皆さまへ</a></li>
                            <li><a href="/school/parent.php">保護者の皆さまへ</a></li>
                            <li><a href="/carriercanter/carriercanter.php">企業の皆さまへ</a></li>
                            <li><a href="/inquiry.php">お問い合わせ</a></li>
                            <li><a href="/faq.php">Q&amp;A</a></li>
                            
                        </ul>
                    </div>
        </div>
    </header>
    <!--header/-->

    <div class="stiky onlyPC">
        <ul class="left_list">
            <li class="news">
                <p class="ttl">N E W S</p>
            </li>
        <li><a href="/experience/">オープン<br>キャンパス</a></li>
            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=5&fsno=1&openExternalBrowser=1" target="_blank">オープンキャンパスの<br>お申し込みはこちら</a></li>
            
            <li><a href="/experience/">イ ベ ン ト</a></li>
        </ul>
        <ul class="right_list">
            <!-- <li><a href="https://technosac.jp/entry/tour.php">学 校 見 学</a></li> -->
            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">入学説明会</a></li>
            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">保護者説明会</a></li>
        <li><a href="/school/collagecourse.php">大学コース</a></li>
        </ul>
    
        <div class="news_inner">
            
            <div class="ttl_area">
            <img src="/new/img/news_ttl.png" alt="NEWS">
            <a href="/weblog/news/" class="more">NEWS一覧はこちら</a>
                <p class="close"></p>
            </div>

            <div class="news_cont">
            
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/02/26/1459.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.02.26</p>
                            <p class="newstitle">【卒業生の皆さまへ】お知らせとお願い</p>
                            <p class="newstxt">
</p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1659.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【オープンキャンパス参加および学校見学ご希望の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/10/01/1156.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.10.01</p>
                            <p class="newstitle">【2021年4月入学をご検討の皆さまへ】AO入学① エントリー期間延長</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/20/0000.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.20</p>
                            <p class="newstitle">2020 TECHNOS祭　9/20～9/22開催</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.15</p>
                            <p class="newstitle">高等教育の修学支援新制度の対象校となりました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/2056.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">日本学生支援機構奨学金二次募集のお知らせ</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/1400.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">【卒業年次在校生・保護者(保証人)の皆さまへ】在学一年延長選択制度　最終申請</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/08/03/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.08.03</p>
                            <p class="newstitle">夏季休業期間中の窓口業務について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/06/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.06</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】学生支援緊急給付金２次募集について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/01/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.01</p>
                            <p class="newstitle">オープンキャンパスに参加される皆さんへ 新型コロナウイルス感染拡大予防について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/06/15/1349.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.06.15</p>
                            <p class="newstitle">本日より新入生の分散登校が開始されました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
            
            </div>
        </div>
        <!--news_inner-->
    
    </div>

<!--SPニュース-->

<div class="foot_bnr_area">
    <!--<a href="/admission/" class="bnr ao_bnr onlySP"><img src="/new/img/header_bnr_college_sp.png" alt="まだ間に合う！大学コース"></a>-->
    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="bnr">
        <img class="onlyPC" src="/new/img/bnr_education.png" alt="高等教育の就学支援新制度の対象行となりました。">
        <img class="onlySP" src="/new/img/bnr_education_sp.png" alt="高等教育の就学支援新制度の対象行となりました。">
    </a>
</div>

    <div class="oc_btn onlySP cf">
            <p class="news_btn">NEWS</p>
            <a href="/experience/" class="oc">オープンキャンパス</a>

            <div class="news_inner">
                <div class="ttl_area">
                    <img src="/new/img/news_ttl.png" alt="NEWS">
                    <a href="/weblog/news/" class="more">NEWS一覧はこちら</a>
                    <p class="close"></p>
                </div>

                <div class="news_cont">
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/02/26/1459.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.02.26</p>
                            <p class="newstitle">【卒業生の皆さまへ】お知らせとお願い</p>
                            <p class="newstxt">
</p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1659.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【オープンキャンパス参加および学校見学ご希望の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/10/01/1156.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.10.01</p>
                            <p class="newstitle">【2021年4月入学をご検討の皆さまへ】AO入学① エントリー期間延長</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/20/0000.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.20</p>
                            <p class="newstitle">2020 TECHNOS祭　9/20～9/22開催</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.15</p>
                            <p class="newstitle">高等教育の修学支援新制度の対象校となりました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/2056.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">日本学生支援機構奨学金二次募集のお知らせ</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/1400.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">【卒業年次在校生・保護者(保証人)の皆さまへ】在学一年延長選択制度　最終申請</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/08/03/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.08.03</p>
                            <p class="newstitle">夏季休業期間中の窓口業務について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/06/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.06</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】学生支援緊急給付金２次募集について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/01/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.01</p>
                            <p class="newstitle">オープンキャンパスに参加される皆さんへ 新型コロナウイルス感染拡大予防について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/06/15/1349.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.06.15</p>
                            <p class="newstitle">本日より新入生の分散登校が開始されました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                
                </div>
            </div>
            <!--news_inner-->
        </div>
        <!--oc_btn-->


    <!---->
   <div class="forobog_wrap">

        <div class="h2_box2">
           <div class="h2_area2">
                <h2><img src="/new/img/forobog/h2_txt.png" alt="卒業生の皆さまへ"></h2>
                <div class="h2_area_photo"><img src="/new/img/forobog/main_img_01.jpg" alt="卒業生写真"></div>
            </div>
        </div>
        <div class="h2_area_photoSP"><img src="/new/img/forobog/main_img_01.jpg" alt="卒業生写真"></div>

       <div id="forobog">
            <div class="inner forobog_B">           
                <h3>卒業生の諸証明等申込みについて</h3>
                <div class="cont_bs02">
                    <p>卒業後の各種証明書類のご請求方法は以下の二つの方法にて承ります。《電話、ファックスでのお申込みはお受けできませんのでご了承ください。》また、証明書の発行は全て有料になります。</p>
                    
                    <div class="foro_ttl01">1：直接来校される場合<span>（本人確認できる証明書ご持参願います）</span></div>
                    <p>事務局備え付けの「証明書発行願」に必要事項を記入し受付にお出しください。20～30分程度で発行できます。（注1、注2）〈事務局での取扱いは月曜～金曜9：00-17：00（土日祭日除く）になります〉</p>
                    <p class="indent_t"><small>注1：英文での証明書は、2～3日かかります。</small></p>
<p class="indent_t"><small>注2：卒業年度によっては卒業確認に多少お時間がかかる事もあります。<br>
また小金井校舎以前の方の成績証明書についてもお時間をいただきますので、お急ぎの方は予め電話等でのお問合せをいただければ幸いです。</small></p>


                    <div class="foro_ttl01">2：郵送によるご請求の場合<span>（本人確認できる証明書のコピーを同封願います）<sup>※</sup><br>※確認後は適正に廃棄いたします。</span></div>
                    <p><small>このページ内の申込みフォームをダウンロードしてプリントアウトしてください。</small></p>
                    <p>必要事項をご記入の上、手数料＋送料（＝合計金額分の切手で可＝）を同封の上、事務局：証明書係へお送りください。届き次第、1～2日（英文は2～3日）で証明書を発行して発送いたしますので、一週間程度の余裕を持ってお申込みください。</p>
            
                    <div class="tbl_block01">
                        <table>
                            <tbody>
                                <tr>
                                    <th width="30%">項　目</th>
                                    <th>タイプ</th>
                                    <th>ダウンロードリンク</th>
                                </tr>
                                <tr>
                                    <td>証明書申込用フォーム</td>
                                    <td><span class="mg01">PDF</span></td>
                                    <td><a href="/info/certificate/technos_form02.pdf" class="pdf_link" target="_blank">ダウンロード</a></td>
                                </tr>
                                <tr>
                                  <td>証明書申込用フォーム</td>
                                  <td>エクセル</td>
                                  <td><a href="/info/certificate/technos_form02.xlsx" class="pdf_link" target="_blank">ダウンロード</a></td>
                                  </tr>
                            </tbody>
                        </table>
                    </div>
            
                    <div class="foro_ttl01">発行手数料<span class="sub_txt"><small>※ 証明書手数料（1通あたり）</small></span></div>
                    <div class="tbl_block01">
                        <table>
                                <tbody>
                                <tr>
                                    <th width="30%">項　目</th>
                                    <th>和　文</th>
                                    <th>英　文</th>
                                  </tr>
                                <tr>
                                    <td>卒業証明書</td>
                                    <td>300円</td>
                                    <td>700円</td>
                                  </tr>
                                <tr>
                                  <td>成績証明書</td>
                                  <td>300円</td>
                                  <td>700円</td>
                                  </tr>
                                <tr>
                                  <td>在籍証明書</td>
                                    <td colspan="2" class="tl01"><span class="mg02">500円</td>
                                  </tr>
                                <tr>
                                  <td>単位習得（修得）証明書</td>
                                  <td colspan="2" class="tl01"><span class="mg02">700円</span></td>
                                  </tr>
                                <tr>
                                  <td>その他</td>
                                  <td colspan="2" class="tl01"><span class="mg02">700円～1000円（証明書発行願の"＊2"を参照願います）</span></td>
                                  </tr>
                                </tbody>
                            </table>
                    </div>
<p class="btmtxt" style="margin:40px 0 -10px!important;">2019年10月1日より郵便料金が変わります。</p>
            
                    <div class="cf" style="margin-top:-20px;">


                        <div class="foro_left01">
                            <div class="foro_ttl01">送　料</div>
                            <div class="cf">
                              <div class="foro_left02">
                            <table>
                            <tbody>
                                <tr>
                                    <td width="50%">和文1</td>
                                    <td>84円</td>
                                </tr>
                                <tr>
                                    <td>和文2～3</td>
                                    <td>94円</td>
                                </tr>
                                <tr>
                                  <td>和文4～8</td>
                                  <td>140円</td>
                              </tr>
                                <tr>
                                  <td>和文9～10</td>
                                  <td>210円</td>
                              </tr>
                            </tbody>
                          </table>
                                </div>
                                <div class="foro_right02">
                            <table>
                            <tbody>
                                <tr>
                                    <td width="50%">英文1～2</td>
                                    <td>120円</td>
                                </tr>
                                <tr>
                                    <td>英文3～6</td>
                                    <td>140円</td>
                                </tr>
                                <tr>
                                  <td>英文7～１0</td>
                                  <td>210円</td>
                              </tr>
                            </tbody>
                          </table>
                                </div>
                            </div>
                        
                        </div>
                        <div class="foro_right01">
                            <div class="foro_ttl01">和文・英文ミックスの場合(一例)</div>
                            <table>
                            <tbody>
                                <tr>
                                    <td width="50%">和文1＋英文1</td>
                                    <td>120円</td>
                                </tr>
                                <tr>
                                    <td>和文2＋英文2</td>
                                    <td>140円</td>
                                </tr>
                                <tr>
                                  <td>和文4＋英文2</td>
                                  <td>140円</td>
                              </tr>
                                <tr>
                                  <td>和文4＋英文4</td>
                                  <td>200円</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                    </div>
                    <p class="btmtxt">※ 『速達』をご希望の方はその旨記載の上、290円切手を追加願います。<br>　（例：「和文1＋速達」の場合→84円+290円=<span style="text-decoration:underline;">374円</span>）</p>
            
            
            
                </div>

                <h3>校友会・同窓会のご紹介</h3>
                <div class="cont_bs02" style="margin-bottom: 10%;">
                    <div class="foro_ttl02">東京工学院専門学校 校友会</div>
                    <p>東京工学院校友会は、平成三年に発足した東京工学院専門学校の卒業生を会員とする卒業生および在校生のための機関です。ホームページでは、総会情報、会報誌、奨学金制度などのご案内をしております。</p>
                    <div class="link_01"><a href="http://www.technos-koyukai.jp/" target="_blank">東京工学院専門学校 校友会</a></div>
                    
                    <div class="foro_ttl03">東京エアトラベル・ホテル専門学校 同窓会</div>
                    <p>東京エアトラベル・ホテル専門学校同窓会は、平成七年に発足した東京エアトラベル・ホテル専門学校の卒業生を会員とする卒業生および在校生のための機関です。ホームページでは、活動報告や会員限定ページの年次会計報告などを設置しています。</p>
                    <div class="link_02"><a href="http://www.airtra.info/" target="_blank">東京エアトラベル・ホテル専門学校 同窓会</a></div>
                </div>


                <div id="recruit" style="margin-top:-67px;padding-top:67px;">
<h3 >教員募集のお知らせ</h3>
                <div class="cont_bs02 recruitBlock">
                    <div class="recruitBlock__inner">
                        <p class="recruitBlock__txt">学校法人田中育英会<br>総合学院テクノスカレッジ<br>東京工学院専門学校／東京エアトラベル・ホテル専門学校</p>
                        <dl>
                            <dt>教員募集のお知らせ</dt>
                            <dd>卒業生の皆さまが社会で活躍してきたスキルを後輩の育成にお役立てください。</dd>
                        </dl>
                    </div>
                    <div class="recruitBlock__inner">
                        <dl>
                            <dt>お問合せ先</dt>
                            <dd>〒184-8543 東京都小金井市前原町5-1-29<br>総合学院テクノスカレッジ<br>東京工学院専門学校／東京エアトラベル・ホテル専門学校</dd>
                        </dl>
                        <p class="recruitBlock__tel">TEL：042-387-5111</p>
                        <p class="recruitBlock__mail">E-mail：<a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;&#105;n&#102;&#111;&#64;&#116;ec&#104;n&#111;s&#46;&#97;&#99;.jp">&#105;n&#102;&#111;&#64;&#116;ec&#104;n&#111;s.&#97;&#99;&#46;jp</a></p>
                    </div>
                </div>
</div><!--recruit-->
        
        
        
        
        
            </div>
        </div>
       
        
        
        <!--
        <div id="admission">
            <div class="inner">
                
                


            </div>
        </div>
        -->
   
    </div><!--admission_wrap/-->
   <!--/footer-->
    <footer>
    	<div class="inner">
            <p>お電話でのご相談や資料請求・来校のご予約はこちらまで</p>
            <div class="cf">
                <dl>
                    <dt>東京工学院専門学校</dt>
                    <dd><img src="/new/img/kogyo_tel.png" alt="0120-634-200"></dd>
                </dl>
                <dl>
                    <dt>東京エアトラベル・ホテル専門学校</dt>
                    <dd><img src="/new/img/air_tel.png" alt="0120-634-300"></dd>
                </dl>
            </div>

            <div class="add cf">
                <div class="logo">
                <a href="/"><img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a>
                    <p>総合学院テクノスカレッジ</p>
                </div>
                <div class="add_box">
                    <p>府中・小金井インテリジェントキャンパス ： <br class="onlySP">〒184-8543 東京都小金井市前原町5-1-29</p>
                    <p>渋谷サテライトキャンパス ： <br class="onlySP">〒151-0051 東京都渋谷区千駄ケ谷5-30-16</p>
                </div>
                    
                <div class="footerMenu">
                    <a href="/privacypolicy.php">プライバシーポリシー</a>
                </div>
            
            </div>

            <p class="copyright">Copyright © Technos College. All Rights Reserved.</p>
        </div>

        <p id="gotop"><img src="/new/img/gotop.png" alt="gotop"></p>
    </footer>
    <!--footer/-->


</div><!--wrapper/-->

<script type="text/javascript" class="microad_blade_track">
<!--
var microad_blade_jp = microad_blade_jp || { 'params' : new Array(), 'complete_map' : new Object() };
(function() {
var param = {'co_account_id' : '24', 'group_id' : '', 'country_id' : '1', 'ver' : '2.1.0'};

var param_custom =
{
"set_1": {
"item" : "rsnemibl20160805079",
}
}
param.custom = param_custom;

microad_blade_jp.params.push(param);

var src = (location.protocol == 'https:')
? 'https://d-track.send.microad.jp/js/blade_track_jp.js' : 'http://d-cache.microad.jp/js/blade_track_jp.js';

var bs = document.createElement('script');
bs.type = 'text/javascript'; bs.async = true;
bs.charset = 'utf-8'; bs.src = src;

var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(bs, s);
})();
-->
</script>

<!-- add. 0909 recruit -->
<script type="text/javascript" class="microad_blade_track">
<!--
var microad_blade_jp = microad_blade_jp || { 'params' : new Array(), 'complete_map' : new Object() };
(function() {
var param = {'co_account_id' : '24', 'group_id' : '', 'country_id' : '1', 'ver' : '2.1.0'};
microad_blade_jp.params.push(param);

var src = (location.protocol == 'https:')
? 'https://d-track.send.microad.jp/js/blade_track_jp.js' : 'http://d-cache.microad.jp/js/blade_track_jp.js';

var bs = document.createElement('script');
bs.type = 'text/javascript'; bs.async = true;
bs.charset = 'utf-8'; bs.src = src;

var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(bs, s);
})();
-->
</script>


</body>
</html>



<!--   お問い合わせ   -->

<!DOCTYPE html>
<html lang="ja">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>よくあるご質問 | 東京工学院専門学校 / 東京エアトラベル・ホテル専門学校</title>
    <meta name="keywords" content="よくあるご質問総合学院テクノスカレッジ,東京工学院専門学校,東京エアトラベル・ホテル専門学校" />
    <meta name="description" content="" />
    <meta name="format-detection" content="telephone=no">
    <link rel="canonical" href="" />
    <link rel="shortcut icon" type="image/x-icon" href="/lib/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

<script type="text/javascript" src="//www2.infoclipper.net/infohp_js/751c6lf.js" charset="UTF-8"></script>
<script type="text/javascript" src="//www2.infoclipper.net/infohp_js/fpAnalysis.js" charset="UTF-8"></script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NF9PB6Z');</script>
<!-- End Google Tag Manager -->
    <!--CSS File-->
    <link rel="stylesheet" type="text/css" href="/new/css/reset.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/common.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/new/css/pc_style.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/sp_style.css" media="screen,print">

    <!--TOP CSS-->
<link rel="stylesheet" type="text/css" href="/new/css/faq/pc_style.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/faq/sp_style.css" media="screen,print">

    
    

    <!--JS File-->
    <script type="text/javascript" src="/new/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/new/js/jquery.matchHeight.js"></script>
    <script type="text/javascript" src="/new/js/jquery.inview.js"></script>
<script type="text/javascript" src="/new/js/custom.js"></script>
<script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script>

    <!--<script type="text/javascript" src="/new/js/jquery.bxslider.min.js"></script>-->

    
    
    
<script type="text/javascript" src="/lib/js/ga.js"></script>
</head>
<body >
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NF9PB6Z"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="fakeLoader"></div>
<div class="wrapper">
    

    <!--/header-->
    <header>
        <div class="inner cf onlyPC">
            <div class="h1_box">
                <a href="/"><h1>総合学院テクノスカレッジ</h1>
            <img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a>    
            </div>
        
            <nav>
            <!--<a href="/admission/" class="bnr"><img src="/new/img/header_bnr_college.png" alt="まだ間に合う！大学コース"></a>-->
                <div class="sns">
                <a href="/experience/" class="oc_btn_head">オープンキャンパス</a>
                    <ul>
                        <li><a href="https://technosac.jp/weblog/" target="_blank">テクノスブログ</a></li>
                    </ul>
                </div>


                <div class="main_menu">
                    <ul class="mainlist">
                        <li><a href="/eng/">東京工学院専門学校</a></li>
                        <li><a href="/air/">東京エアトラベル・ホテル<br />専門学校</a></li>
                        <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1" target="_blank">資料請求</a></li>
                        <li><a href="/access.php">アクセス</a></li>
                        <li><a class="menu_btn"><span class="menu_btn-icon"></span>MENU</a></li>
                    </ul>

                    <div class="nav_inner cf">
                        <dl class="menulist">
                            <dt><a href="/admission/">入学のご案内</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/admission/">募集要項・学費・奨学金</a></li>
                                    <li><a href="/admission/admission.php">入学までの流れ</a></li>
                                    <li><a href="/admission/selection.php">選考方法</a></li>
                                    <li><a href="/admission/ao.php">AO入学</a></li>
                                    <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker01">各種奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
                                    <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <dl class="menulist">
                            <dt><a href="/school/">学院案内／教育理念</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/school/greetings.php#unker02">理事長挨拶</a></li>
                                    <li><a href="/school/greetings.php#unker01">建学の精神</a></li>
                                    <li><a href="/school/greetings.php#unker04">沿革</a></li>
                                    <li><a href="/school/greetings.php#unker03">学院長挨拶</a></li>
                                <li><a href="/school/greetings.php/#unker05">情報公開</a></li>
                                </ul>
                            </dd>
                            <dt><a href="/campus/">キャンパスライフ</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/campus/facilities.php">施設紹介</a></li>
                                    <li><a href="/campus/club.php">部活・クラブ紹介</a></li>
                                    <li><a href="/campus/internationalweek.php">インターナショナルウィーク</a></li>
                                    <li><a href="/campus/twinneduniv.php">海外姉妹校の紹介</a></li>
                                <li><a href="/campus/sandwich-study-abroad.php">サンドイッチ留学</a></li>
                                    <li><a href="/campus/eng-year-event.php">東京工学院専門学校 年間イベント</a></li>
                                    <li><a href="/campus/air-year-event.php">東京エアトラベル・ホテル専門学校 年間イベント</a></li>
                                </ul>
                            </dd>
                            <dt>就職への取り組み</dt>
                            <dd>
                                <ul>
                                    <li><a href="/manabi/career.php">キャリア支援プログラム</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <ul class="link_list">
                            <li><a href="/eng/">東京工学院専門学校</a></li>
                            <li><a href="/air/">東京エアトラベル・ホテル専門学校</a></li>
                        <li><a href="/manabi/prag.php">PRAGについて</a></li>
                        <li><a href="/manabi/seminar.php">TECHNOS ゼミについて</a></li>
                            <li><a href="/school/collagecourse.php">大学コース</a></li>
                            <li><a href="/experience/">オープンキャンパス</a></li>
                            <li><a href="/access.php">アクセス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1">資料請求</a></li>
                            <li><a href="/forobog.php">卒業生の皆さまへ</a></li>
                            <li><a href="/school/parent.php">保護者の皆さまへ</a></li>
                            <li><a href="/carriercanter/carriercanter.php">企業の皆さまへ</a></li>
                            <li><a href="/inquiry.php">お問い合わせ</a></li>
                            <li><a href="/faq.php">Q&amp;A</a></li>
                        <li class="middle"><a href="https://technosac.jp/weblog/" target="_blank">テクノスブログ</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

        <div class="onlySP">
            <ul class="main_nav cf">
                <li><a href="/"><img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a></li>
                <li><a href="/eng/"><img src="/new/img/sp_menu01.png" alt="東京工学院専門学校"></a></li>
                <li><a href="/air/"><img src="/new/img/sp_menu02.png" alt="東京エアトラベル・ホテル専門学校"></a></li>
                <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1"><img src="/new/img/sp_menu03.png" alt="資料請求"></a></li>
                <li><a href="/access.php"><img src="/new/img/sp_menu04.png" alt="アクセス"></a></li>
                <li><a class="menu_btn"><span class="menu_btn-icon"></span><p>MENU</p></a></li>
            </ul>

            <div class="nav_inner cf">
                <div class="sns">
                    <ul>
                        <li class="blog"><a href="/weblog/" target="_blank"><img src="/new/img/head_blog_sp.png" alt="BLOG">テクノスブログ</a></li>
                        <!--<li><a href="" target="_blank"><img src="/new/img/head_twitter_sp.png" alt="Twitter"></a></li>
                        <li><a href="" target="_blank"><img src="/new/img/head_fb_sp.png" alt="Facebook"></a></li>
                        <li><a href="" target="_blank"><img src="/new/img/head_line_sp.png" alt="LINE@"></a></li>-->
                    </ul>
                </div>

                        <dl class="menulist">
                            <dt class="acc"><a href="/admission/">入学のご案内</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/admission/">募集要項・学費・奨学金</a></li>
                                    <li><a href="/admission/admission.php">入学までの流れ</a></li>
                                    <li><a href="/admission/selection.php">選考方法</a></li>
                                    <li><a href="/admission/ao.php">AO入学</a></li>
                                    <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker01">各種奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
                                    <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <dl class="menulist">
                            <dt class="acc"><a href="/school/">学院案内／教育理念</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/school/greetings.php#unker02">理事長挨拶</a></li>
                                    <li><a href="/school/greetings.php#unker01">建学の精神</a></li>
                                    <li><a href="/school/greetings.php#unker04">沿革</a></li>
                                    <li><a href="/school/greetings.php#unker03">学院長挨拶</a></li>
                                <li><a href="/school/greetings.php/#unker05">情報公開</a></li>
                                </ul>
                            </dd>
                            <dt class="acc"><a href="/campus/">キャンパスライフ</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/campus/facilities.php">施設紹介</a></li>
                                    <li><a href="/campus/club.php">部活・クラブ紹介</a></li>
                                    <li><a href="/campus/internationalweek.php">インターナショナルウィーク</a></li>
                                    <li><a href="/campus/twinneduniv.php">海外姉妹校の紹介</a></li>
                                <li><a href="/campus/sandwich-study-abroad.php">サンドイッチ留学</a></li>
                                    <li><a href="/campus/eng-year-event.php">東京工学院専門学校 年間イベント</a></li>
                                    <li><a href="/campus/air-year-event.php">東京エアトラベル・ホテル専門学校 年間イベント</a></li>
                                </ul>
                            </dd>
                            <dt class="acc">就職への取り組み</dt>
                            <dd>
                                <ul>
                                    <li><a href="/manabi/career.php">キャリア支援プログラム</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <ul class="link_list">
                            <li><a href="/eng/">東京工学院専門学校</a></li>
                            <li><a href="/air/">東京エアトラベル・ホテル専門学校</a></li>
                        <li><a href="/manabi/prag.php">PRAGについて</a></li>
                        <li><a href="/manabi/seminar.php">TECHNOS ゼミについて</a></li>
                            <li><a href="/school/collagecourse.php">大学コース</a></li>
                            <li><a href="/experience/">オープンキャンパス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=5&fsno=1&openExternalBrowser=1" target="_blank">オープンキャンパスのお申し込みはこちら</a></li>
                            <!-- <li><a href="https://technosac.jp/entry/tour.php">学校見学</a></li> -->
                            <li><a href="/experience/">イベント</a></li>
                        <!--
                            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">入学説明会</a></li>
                            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">保護者説明会</a></li>
                            <li><a href="/experience/#daigaku_course">大学コース説明</a></li>
                        -->
                            <li><a href="/access.php">アクセス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1">資料請求</a></li>
                            <li><a href="/forobog.php">卒業生の皆さまへ</a></li>
                            <li><a href="/school/parent.php">保護者の皆さまへ</a></li>
                            <li><a href="/carriercanter/carriercanter.php">企業の皆さまへ</a></li>
                            <li><a href="/inquiry.php">お問い合わせ</a></li>
                            <li><a href="/faq.php">Q&amp;A</a></li>
                            
                        </ul>
                    </div>
        </div>
    </header>
    <!--header/-->

    <div class="stiky onlyPC">
        <ul class="left_list">
            <li class="news">
                <p class="ttl">N E W S</p>
            </li>
        <li><a href="/experience/">オープン<br>キャンパス</a></li>
            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=5&fsno=1&openExternalBrowser=1" target="_blank">オープンキャンパスの<br>お申し込みはこちら</a></li>
            
            <li><a href="/experience/">イ ベ ン ト</a></li>
        </ul>
        <ul class="right_list">
            <!-- <li><a href="https://technosac.jp/entry/tour.php">学 校 見 学</a></li> -->
            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">入学説明会</a></li>
            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">保護者説明会</a></li>
        <li><a href="/school/collagecourse.php">大学コース</a></li>
        </ul>
    
        <div class="news_inner">
            
            <div class="ttl_area">
            <img src="/new/img/news_ttl.png" alt="NEWS">
            <a href="/weblog/news/" class="more">NEWS一覧はこちら</a>
                <p class="close"></p>
            </div>

            <div class="news_cont">
            
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/02/26/1459.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.02.26</p>
                            <p class="newstitle">【卒業生の皆さまへ】お知らせとお願い</p>
                            <p class="newstxt">
</p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1659.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【オープンキャンパス参加および学校見学ご希望の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/10/01/1156.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.10.01</p>
                            <p class="newstitle">【2021年4月入学をご検討の皆さまへ】AO入学① エントリー期間延長</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/20/0000.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.20</p>
                            <p class="newstitle">2020 TECHNOS祭　9/20～9/22開催</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.15</p>
                            <p class="newstitle">高等教育の修学支援新制度の対象校となりました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/2056.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">日本学生支援機構奨学金二次募集のお知らせ</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/1400.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">【卒業年次在校生・保護者(保証人)の皆さまへ】在学一年延長選択制度　最終申請</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/08/03/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.08.03</p>
                            <p class="newstitle">夏季休業期間中の窓口業務について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/06/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.06</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】学生支援緊急給付金２次募集について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/01/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.01</p>
                            <p class="newstitle">オープンキャンパスに参加される皆さんへ 新型コロナウイルス感染拡大予防について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/06/15/1349.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.06.15</p>
                            <p class="newstitle">本日より新入生の分散登校が開始されました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
            
            </div>
        </div>
        <!--news_inner-->
    
    </div>

<!--SPニュース-->

<div class="foot_bnr_area">
    <!--<a href="/admission/" class="bnr ao_bnr onlySP"><img src="/new/img/header_bnr_college_sp.png" alt="まだ間に合う！大学コース"></a>-->
    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="bnr">
        <img class="onlyPC" src="/new/img/bnr_education.png" alt="高等教育の就学支援新制度の対象行となりました。">
        <img class="onlySP" src="/new/img/bnr_education_sp.png" alt="高等教育の就学支援新制度の対象行となりました。">
    </a>
</div>

    <div class="oc_btn onlySP cf">
            <p class="news_btn">NEWS</p>
            <a href="/experience/" class="oc">オープンキャンパス</a>

            <div class="news_inner">
                <div class="ttl_area">
                    <img src="/new/img/news_ttl.png" alt="NEWS">
                    <a href="/weblog/news/" class="more">NEWS一覧はこちら</a>
                    <p class="close"></p>
                </div>

                <div class="news_cont">
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/02/26/1459.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.02.26</p>
                            <p class="newstitle">【卒業生の皆さまへ】お知らせとお願い</p>
                            <p class="newstxt">
</p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1659.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【オープンキャンパス参加および学校見学ご希望の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/10/01/1156.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.10.01</p>
                            <p class="newstitle">【2021年4月入学をご検討の皆さまへ】AO入学① エントリー期間延長</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/20/0000.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.20</p>
                            <p class="newstitle">2020 TECHNOS祭　9/20～9/22開催</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.15</p>
                            <p class="newstitle">高等教育の修学支援新制度の対象校となりました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/2056.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">日本学生支援機構奨学金二次募集のお知らせ</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/1400.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">【卒業年次在校生・保護者(保証人)の皆さまへ】在学一年延長選択制度　最終申請</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/08/03/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.08.03</p>
                            <p class="newstitle">夏季休業期間中の窓口業務について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/06/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.06</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】学生支援緊急給付金２次募集について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/01/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.01</p>
                            <p class="newstitle">オープンキャンパスに参加される皆さんへ 新型コロナウイルス感染拡大予防について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/06/15/1349.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.06.15</p>
                            <p class="newstitle">本日より新入生の分散登校が開始されました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                
                </div>
            </div>
            <!--news_inner-->
        </div>
        <!--oc_btn-->


    <!---->
   <div class="faq_wrap">

        <div class="h2_box2">
           <div class="h2_area2">
				<h2><img src="/new/img/faq/h2_txt.png" alt="よくあるご質問"></h2>
				<div class="h2_area_photo"><img src="/new/img/faq/main_img_01.jpg" alt="写真"></div>
			</div>
        </div>
        <div class="h2_area_photoSP"><img src="/new/img/faq/main_img_01.jpg" alt="写真"></div>

       <div id="faq">
			<div class="inner faq_B">        	
				<div class="faq_ttl"><img src="/new/img/faq/txt_img_01.png" alt="知って安心! 聞いて納得!"></div>
				
				<div class="cont_bs02">
				<p>学校を選ぶ時に皆さんが知っておきたいこと、聞いてみたいことを今まで数多くあった質問の中からいくつか用意しました。</p> 

  				<div class="anker_list cf">
   				<ul>
   					<li class="match"><a href="#anker01">願書の出願期間は?</a></li>
   					<li class="match"><a href="#anker02">大学に行こうか専門学校に行こうか迷っているのですが...</a></li>
   					<li class="match"><a href="#anker03">実家から遠いので学校の近くから通いたいのですが、どのような物件がありますか?</a></li>
   					<li class="match"><a href="#anker04">授業料は？</a></li>
   					<li class="match"><a href="#anker05">英語が苦手ですが、何とか伸ばして就職に結び付けたいのですが...</a></li>
   					<li class="match"><a href="#anker06">エアラインコースを選択したら、就職の際航空業界しか受けられませんか?</a></li>
   					<li class="match"><a href="#anker07">たくさんの設備・施設がありますが、授業以外にも自由に使用することはできますか?</a></li>
   					<li class="match"><a href="#anker08">学校の雰囲気を知りたいのですが</a></li>
   					<li class="match"><a href="#anker09">授業時間や休み時間は?</a></li>
   					<li class="match"><a href="#anker10">私はサッカーが大好きで、入学後も続けたいのですが...</a></li>
   					<li class="match"><a href="#anker11">奨学金制度を利用したいのですが、どのような制度がありますか?</a></li>
   					<li class="match"><a href="#anker12">1クラス何人ですか?</a></li>
   					<li class="match"><a href="#anker13">実際の授業はどんな感じですか?</a></li>
   					<li class="match"><a href="#anker14">専門学校は課題が多いというイメージがあるので心配です。実際はどうなのでしょうか?</a></li>
   					<li class="match"><a href="#anker15">国内だけでなく、海外の技術や知識も得たいのですが、海外研修などはありますか?</a></li>
   				</ul>
				</div>
				<!-----answer----->

				<dl class="faq_B_dl1" name="anker01" id="anker01">
					<dt>願書の出願期間は?</dt>
					<dd><p>願書の受付は、10月1日〜3月31日までです。すでに高等学校を卒業している方の願書は9月1日より受付けます。提出方法は、願書書留郵送用封筒にて郵送していただくか、総合学院テクノスカレッジ 事務局 入学課の窓口でも受付けています。</p></dd>
				</dl>
           		<dl class="faq_B_dl2" name="anker02" id="anker02">
					<dt>大学に行こうか専門学校に行こうか迷っているのですが・・・</dt>
					<dd><p>東京工学院、または、東京エアトラベル・ホテル専門学校を卒業して大学の3年に編入したり、本校で学びながら産能短期大学を併修し、卒業と同時に専門士、準学士の両方の資格を取得することもできます。行きたい道が決まっているのならば、企業と直結したパイプを持つ「総合学院テクノスカレッジ」で自分の夢を実現するのが近道です!</p></dd>
				</dl>
				<dl class="faq_B_dl1" name="anker03" id="anker03">
					<dt>実家から遠いので学校の近くから通いたいのですが、どのような物件がありますか?</dt>
					<dd>
						<p>アパート相談室では、学校周辺の優良物件をご紹介しています。指定学生会館・寮も学校近くにありますので、お気軽にご相談ください。</p>
						<p>アパート相談室 <em class="pctel">042-387-5111</em><em class="sptel"><a href="tel:0423875111">042-387-5111</a></em></p>
						<div class="cf">
							<div class="faq_left01">
								<p>提携学生会館</p>
							</div>
							<div class="faq_right01">
								<p>共立メンテナンス <em class="pctel">0120-88-1030</em><em class="sptel"><a href="tel:0120881030">0120-88-1030</a></em><br>東仁学生会館 <em class="pctel">0120-88-5575</em> <em class="sptel"><a href="tel:0120885575">0120-88-5575</a></em></p>
							</div>
						</div>
					</dd>
				</dl>
           		<dl class="faq_B_dl2" name="anker04" id="anker04">
					<dt>授業料は?</dt>
					<dd><p>年間授業料は、募集要項に詳しく載っていますので参考にして下さい。AO入試システムや、特待生チャレンジ試験、それに各種検定資格も入試の際考慮してくれるシステムがありますので参考にしてください。授業料の分納もできます。</p></dd>
				</dl>
				<dl class="faq_B_dl1" name="anker05" id="anker05">
					<dt>英語が苦手ですが、何とか伸ばして就職に結び付けたいのですが・・・</dt>
					<dd>
						<p>頑張り次第で、一年間でTOEICの点数が250点アップした学生も多数います。英会話の授業もレベルに合った少人数クラスで構成。ネイティブの先生との会話でかなり上達します。</p>
					</dd>
				</dl>
           		<dl class="faq_B_dl2" name="anker06" id="anker06">
					<dt>エアラインコースを選択したら、就職の際航空業界しか受けられませんか?</dt>
					<dd><p>｢エアトラ｣では、学科に関係なく語学、コンピューター、ホスピタリティマナー、手話などを学びますので、就職先を考えるとき、自分を改めて見直し、ホテル、旅行業界と、新たなチャレンジの機会はさらに広がります。</p></dd>
				</dl>
				<dl class="faq_B_dl1" name="anker07" id="anker07">
					<dt>たくさんの設備・施設がありますが、授業以外にも自由に使用することはできますか?</dt>
					<dd>
						<p>担当の教員に許可を取れば基本的には使用できます。授業外にも施設や設備を充分に活用し、自分の力を伸ばしてください。</p>
					</dd>
				</dl>
           		<dl class="faq_B_dl2" name="anker08" id="anker08">
					<dt>学校の雰囲気を知りたいのですが?</dt>
					<dd><p>学校のことで疑問や質問があれば、学校説明会へどうぞ。また、体験入学では実際の授業を受けられるので、授業の進め方や雰囲気を感じていただけると思います。学校説明会、体験入学にお気軽にご参加ください。</p></dd>
				</dl>
				<dl class="faq_B_dl1" name="anker09" id="anker09">
					<dt>授業時間や休み時間は?</dt>
					<dd>
						<p>｢エアトラ｣の授業時間は1コマ50分授業で、東京工学院は科によって変わります。詳しくは各コースの紹介ページをご覧下さい。日によって始業時間、終了時間が変わりますので、空いた時間に図書館を利用したり、中庭やカフェテリアで過ごすことができます。</p>
					</dd>
				</dl>
           		<dl class="faq_B_dl2" name="anker10" id="anker10">
					<dt>私はサッカーが大好きで、入学後も続けたいのですが・・・</dt>
					<dd><p>総合学院テクノスカレッジには、体育系、文科系と各種クラブ活動があります。サッカーやバドミントンは東京都の専門学校大会で優秀な成績を残した実績があります。</p></dd>
				</dl>
				<dl class="faq_B_dl1" name="anker11" id="anker11">
					<dt>奨学金制度を利用したいのですが、どのような制度がありますか?</dt>
					<dd>
						<p>本校の奨学金制度は、無利子貸与の奨学金として「田中育英会奨学金制度｣と｢校友会・同窓会奨学金制度」、自宅外通学者のための返金不要の奨学金として、「自宅外通学者補助制度」などがあります。その他には公的な奨学金制度の利用も可能です。</p>
					</dd>
				</dl>
           		<dl class="faq_B_dl2" name="anker12" id="anker12">
					<dt>1クラス何人ですか?</dt>
					<dd><p>各学科によってそれぞれ違いますが、1クラスの定員は20名〜40名です。少人数制にすることで一人ひとりにきめ細やかな実習や指導が受けられます。</p></dd>
				</dl>
				<dl class="faq_B_dl1" name="anker13" id="anker13">
					<dt>実際の授業はどんな感じですか?</dt>
					<dd>
						<p>理論や基礎知識を学ぶことはもちろん、充実した学習機材、施設を利用して実習形式で実際の現場と同じワークフローで実践力を身につけます。校外イベントへの出展やインターンシップ(職場体験)など実践的なカリキュラムを展開しています。</p>
					</dd>
				</dl>
           		<dl class="faq_B_dl2" name="anker14" id="anker14">
					<dt>専門学校は課題が多いというイメージがあるので心配です。実際はどうなのでしょうか?</dt>
					<dd><p>学科にもよりますが、実習の後のレポートや、教員によっては特別に課題を出すこともあります。しかし、毎日徹夜をしなければ終らないような課題はありません。</p></dd>
				</dl>
				<dl class="faq_B_dl1 bdnone" name="anker15" id="anker15">
					<dt>国内だけでなく、海外の技術や知識も得たいのですが、海外研修などはありますか?</dt>
					<dd>
						<p>成績優秀者は姉妹校へ短期留学のチャンスがあります!留学先では語学研修と各学科の専門分野を学ぶことができ、自分の能力と、可能性を広げるにはとても良い経験になると思うので、頑張ってみてください!</p>
					</dd>
				</dl>
				
				
				
				<!-----answer----->
     			
      			</div>
      			       	
        	</div>
        </div>
       
        
        
        <!--
        <div id="admission">
            <div class="inner">
                
                


            </div>
        </div>
		-->
   
    </div><!--admission_wrap/-->
   <!--/footer-->
    <footer>
    	<div class="inner">
            <p>お電話でのご相談や資料請求・来校のご予約はこちらまで</p>
            <div class="cf">
                <dl>
                    <dt>東京工学院専門学校</dt>
                    <dd><img src="/new/img/kogyo_tel.png" alt="0120-634-200"></dd>
                </dl>
                <dl>
                    <dt>東京エアトラベル・ホテル専門学校</dt>
                    <dd><img src="/new/img/air_tel.png" alt="0120-634-300"></dd>
                </dl>
            </div>

            <div class="add cf">
                <div class="logo">
                <a href="/"><img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a>
                    <p>総合学院テクノスカレッジ</p>
                </div>
                <div class="add_box">
                    <p>府中・小金井インテリジェントキャンパス ： <br class="onlySP">〒184-8543 東京都小金井市前原町5-1-29</p>
                    <p>渋谷サテライトキャンパス ： <br class="onlySP">〒151-0051 東京都渋谷区千駄ケ谷5-30-16</p>
                </div>
                    
                <div class="footerMenu">
                    <a href="/privacypolicy.php">プライバシーポリシー</a>
                </div>
            
            </div>

            <p class="copyright">Copyright © Technos College. All Rights Reserved.</p>
        </div>

        <p id="gotop"><img src="/new/img/gotop.png" alt="gotop"></p>
    </footer>
    <!--footer/-->


</div><!--wrapper/-->

<script type="text/javascript" class="microad_blade_track">
<!--
var microad_blade_jp = microad_blade_jp || { 'params' : new Array(), 'complete_map' : new Object() };
(function() {
var param = {'co_account_id' : '24', 'group_id' : '', 'country_id' : '1', 'ver' : '2.1.0'};

var param_custom =
{
"set_1": {
"item" : "rsnemibl20160805079",
}
}
param.custom = param_custom;

microad_blade_jp.params.push(param);

var src = (location.protocol == 'https:')
? 'https://d-track.send.microad.jp/js/blade_track_jp.js' : 'http://d-cache.microad.jp/js/blade_track_jp.js';

var bs = document.createElement('script');
bs.type = 'text/javascript'; bs.async = true;
bs.charset = 'utf-8'; bs.src = src;

var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(bs, s);
})();
-->
</script>

<!-- add. 0909 recruit -->
<script type="text/javascript" class="microad_blade_track">
<!--
var microad_blade_jp = microad_blade_jp || { 'params' : new Array(), 'complete_map' : new Object() };
(function() {
var param = {'co_account_id' : '24', 'group_id' : '', 'country_id' : '1', 'ver' : '2.1.0'};
microad_blade_jp.params.push(param);

var src = (location.protocol == 'https:')
? 'https://d-track.send.microad.jp/js/blade_track_jp.js' : 'http://d-cache.microad.jp/js/blade_track_jp.js';

var bs = document.createElement('script');
bs.type = 'text/javascript'; bs.async = true;
bs.charset = 'utf-8'; bs.src = src;

var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(bs, s);
})();
-->
</script>


</body>
</html>

<!--  スペシャルウィーク   -->

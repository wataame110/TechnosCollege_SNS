<!DOCTYPE html>
<html lang="ja">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>PRAGを通した学び | 東京工学院専門学校 / 東京エアトラベル・ホテル専門学校</title>
    <meta name="keywords" content="PRAGを通した学び総合学院テクノスカレッジ,東京工学院専門学校,東京エアトラベル・ホテル専門学校" />
    <meta name="description" content="" />
    <meta name="format-detection" content="telephone=no">
    <link rel="canonical" href="" />
    <link rel="shortcut icon" type="image/x-icon" href="/lib/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

<script type="text/javascript" src="//www2.infoclipper.net/infohp_js/751c6lf.js" charset="UTF-8"></script>
<script type="text/javascript" src="//www2.infoclipper.net/infohp_js/fpAnalysis.js" charset="UTF-8"></script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NF9PB6Z');</script>
<!-- End Google Tag Manager -->
    <!--CSS File-->
    <link rel="stylesheet" type="text/css" href="/new/css/reset.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/common.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/new/css/pc_style.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/sp_style.css" media="screen,print">

    <!--TOP CSS-->
<link rel="stylesheet" type="text/css" href="/new/css/manabi/pc_style.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/manabi/sp_style.css" media="screen,print">

    
    
    
    <link rel="stylesheet" type="text/css" href="/new/css/slick.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/slick-theme.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/experience/common.css" media="screen,print">
    

    <!--JS File-->
    <script type="text/javascript" src="/new/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/new/js/jquery.matchHeight.js"></script>
    <script type="text/javascript" src="/new/js/jquery.inview.js"></script>
<script type="text/javascript" src="/new/js/custom.js"></script>
<script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script>

    <!--<script type="text/javascript" src="/new/js/jquery.bxslider.min.js"></script>-->

    
<script src="/new/js/manabi/custom.js"></script>


<script type="text/javascript" src="/lib/js/ga.js"></script>
</head>
<body >
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NF9PB6Z"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="fakeLoader"></div>
<div class="wrapper">
    

    <!--/header-->
    <header>
        <div class="inner cf onlyPC">
            <div class="h1_box">
                <a href="/"><h1>総合学院テクノスカレッジ</h1>
            <img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a>    
            </div>
        
            <nav>
            <!--<a href="/admission/" class="bnr"><img src="/new/img/header_bnr_college.png" alt="まだ間に合う！大学コース"></a>-->
                <div class="sns">
                <a href="/experience/" class="oc_btn_head">オープンキャンパス</a>
                    <ul>
                        <li><a href="https://technosac.jp/weblog/" target="_blank">テクノスブログ</a></li>
                    </ul>
                </div>


                <div class="main_menu">
                    <ul class="mainlist">
                        <li><a href="/eng/">東京工学院専門学校</a></li>
                        <li><a href="/air/">東京エアトラベル・ホテル<br />専門学校</a></li>
                        <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1" target="_blank">資料請求</a></li>
                        <li><a href="/access.php">アクセス</a></li>
                        <li><a class="menu_btn"><span class="menu_btn-icon"></span>MENU</a></li>
                    </ul>

                    <div class="nav_inner cf">
                        <dl class="menulist">
                            <dt><a href="/admission/">入学のご案内</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/admission/">募集要項・学費・奨学金</a></li>
                                    <li><a href="/admission/admission.php">入学までの流れ</a></li>
                                    <li><a href="/admission/selection.php">選考方法</a></li>
                                    <li><a href="/admission/ao.php">AO入学</a></li>
                                    <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker01">各種奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
                                    <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <dl class="menulist">
                            <dt><a href="/school/">学院案内／教育理念</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/school/greetings.php#unker02">理事長挨拶</a></li>
                                    <li><a href="/school/greetings.php#unker01">建学の精神</a></li>
                                    <li><a href="/school/greetings.php#unker04">沿革</a></li>
                                    <li><a href="/school/greetings.php#unker03">学院長挨拶</a></li>
                                <li><a href="/school/greetings.php/#unker05">情報公開</a></li>
                                </ul>
                            </dd>
                            <dt><a href="/campus/">キャンパスライフ</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/campus/facilities.php">施設紹介</a></li>
                                    <li><a href="/campus/club.php">部活・クラブ紹介</a></li>
                                    <li><a href="/campus/internationalweek.php">インターナショナルウィーク</a></li>
                                    <li><a href="/campus/twinneduniv.php">海外姉妹校の紹介</a></li>
                                <li><a href="/campus/sandwich-study-abroad.php">サンドイッチ留学</a></li>
                                    <li><a href="/campus/eng-year-event.php">東京工学院専門学校 年間イベント</a></li>
                                    <li><a href="/campus/air-year-event.php">東京エアトラベル・ホテル専門学校 年間イベント</a></li>
                                </ul>
                            </dd>
                            <dt>就職への取り組み</dt>
                            <dd>
                                <ul>
                                    <li><a href="/manabi/career.php">キャリア支援プログラム</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <ul class="link_list">
                            <li><a href="/eng/">東京工学院専門学校</a></li>
                            <li><a href="/air/">東京エアトラベル・ホテル専門学校</a></li>
                        <li><a href="/manabi/prag.php">PRAGについて</a></li>
                        <li><a href="/manabi/seminar.php">TECHNOS ゼミについて</a></li>
                            <li><a href="/school/collagecourse.php">大学コース</a></li>
                            <li><a href="/experience/">オープンキャンパス</a></li>
                            <li><a href="/access.php">アクセス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1">資料請求</a></li>
                            <li><a href="/forobog.php">卒業生の皆さまへ</a></li>
                            <li><a href="/school/parent.php">保護者の皆さまへ</a></li>
                            <li><a href="/carriercanter/carriercanter.php">企業の皆さまへ</a></li>
                            <li><a href="/inquiry.php">お問い合わせ</a></li>
                            <li><a href="/faq.php">Q&amp;A</a></li>
                        <li class="middle"><a href="https://technosac.jp/weblog/" target="_blank">テクノスブログ</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

        <div class="onlySP">
            <ul class="main_nav cf">
                <li><a href="/"><img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a></li>
                <li><a href="/eng/"><img src="/new/img/sp_menu01.png" alt="東京工学院専門学校"></a></li>
                <li><a href="/air/"><img src="/new/img/sp_menu02.png" alt="東京エアトラベル・ホテル専門学校"></a></li>
                <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1"><img src="/new/img/sp_menu03.png" alt="資料請求"></a></li>
                <li><a href="/access.php"><img src="/new/img/sp_menu04.png" alt="アクセス"></a></li>
                <li><a class="menu_btn"><span class="menu_btn-icon"></span><p>MENU</p></a></li>
            </ul>

            <div class="nav_inner cf">
                <div class="sns">
                    <ul>
                        <li class="blog"><a href="/weblog/" target="_blank"><img src="/new/img/head_blog_sp.png" alt="BLOG">テクノスブログ</a></li>
                        <!--<li><a href="" target="_blank"><img src="/new/img/head_twitter_sp.png" alt="Twitter"></a></li>
                        <li><a href="" target="_blank"><img src="/new/img/head_fb_sp.png" alt="Facebook"></a></li>
                        <li><a href="" target="_blank"><img src="/new/img/head_line_sp.png" alt="LINE@"></a></li>-->
                    </ul>
                </div>

                        <dl class="menulist">
                            <dt class="acc"><a href="/admission/">入学のご案内</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/admission/">募集要項・学費・奨学金</a></li>
                                    <li><a href="/admission/admission.php">入学までの流れ</a></li>
                                    <li><a href="/admission/selection.php">選考方法</a></li>
                                    <li><a href="/admission/ao.php">AO入学</a></li>
                                    <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker01">各種奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
                                    <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <dl class="menulist">
                            <dt class="acc"><a href="/school/">学院案内／教育理念</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/school/greetings.php#unker02">理事長挨拶</a></li>
                                    <li><a href="/school/greetings.php#unker01">建学の精神</a></li>
                                    <li><a href="/school/greetings.php#unker04">沿革</a></li>
                                    <li><a href="/school/greetings.php#unker03">学院長挨拶</a></li>
                                <li><a href="/school/greetings.php/#unker05">情報公開</a></li>
                                </ul>
                            </dd>
                            <dt class="acc"><a href="/campus/">キャンパスライフ</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/campus/facilities.php">施設紹介</a></li>
                                    <li><a href="/campus/club.php">部活・クラブ紹介</a></li>
                                    <li><a href="/campus/internationalweek.php">インターナショナルウィーク</a></li>
                                    <li><a href="/campus/twinneduniv.php">海外姉妹校の紹介</a></li>
                                <li><a href="/campus/sandwich-study-abroad.php">サンドイッチ留学</a></li>
                                    <li><a href="/campus/eng-year-event.php">東京工学院専門学校 年間イベント</a></li>
                                    <li><a href="/campus/air-year-event.php">東京エアトラベル・ホテル専門学校 年間イベント</a></li>
                                </ul>
                            </dd>
                            <dt class="acc">就職への取り組み</dt>
                            <dd>
                                <ul>
                                    <li><a href="/manabi/career.php">キャリア支援プログラム</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <ul class="link_list">
                            <li><a href="/eng/">東京工学院専門学校</a></li>
                            <li><a href="/air/">東京エアトラベル・ホテル専門学校</a></li>
                        <li><a href="/manabi/prag.php">PRAGについて</a></li>
                        <li><a href="/manabi/seminar.php">TECHNOS ゼミについて</a></li>
                            <li><a href="/school/collagecourse.php">大学コース</a></li>
                            <li><a href="/experience/">オープンキャンパス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=5&fsno=1&openExternalBrowser=1" target="_blank">オープンキャンパスのお申し込みはこちら</a></li>
                            <!-- <li><a href="https://technosac.jp/entry/tour.php">学校見学</a></li> -->
                            <li><a href="/experience/">イベント</a></li>
                        <!--
                            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">入学説明会</a></li>
                            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">保護者説明会</a></li>
                            <li><a href="/experience/#daigaku_course">大学コース説明</a></li>
                        -->
                            <li><a href="/access.php">アクセス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1">資料請求</a></li>
                            <li><a href="/forobog.php">卒業生の皆さまへ</a></li>
                            <li><a href="/school/parent.php">保護者の皆さまへ</a></li>
                            <li><a href="/carriercanter/carriercanter.php">企業の皆さまへ</a></li>
                            <li><a href="/inquiry.php">お問い合わせ</a></li>
                            <li><a href="/faq.php">Q&amp;A</a></li>
                            
                        </ul>
                    </div>
        </div>
    </header>
    <!--header/-->

    <div class="stiky onlyPC">
        <ul class="left_list">
            <li class="news">
                <p class="ttl">N E W S</p>
            </li>
        <li><a href="/experience/">オープン<br>キャンパス</a></li>
            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=5&fsno=1&openExternalBrowser=1" target="_blank">オープンキャンパスの<br>お申し込みはこちら</a></li>
            
            <li><a href="/experience/">イ ベ ン ト</a></li>
        </ul>
        <ul class="right_list">
            <!-- <li><a href="https://technosac.jp/entry/tour.php">学 校 見 学</a></li> -->
            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">入学説明会</a></li>
            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">保護者説明会</a></li>
        <li><a href="/school/collagecourse.php">大学コース</a></li>
        </ul>
    
        <div class="news_inner">
            
            <div class="ttl_area">
            <img src="/new/img/news_ttl.png" alt="NEWS">
            <a href="/weblog/news/" class="more">NEWS一覧はこちら</a>
                <p class="close"></p>
            </div>

            <div class="news_cont">
            
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/02/26/1459.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.02.26</p>
                            <p class="newstitle">【卒業生の皆さまへ】お知らせとお願い</p>
                            <p class="newstxt">
</p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1659.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【オープンキャンパス参加および学校見学ご希望の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/10/01/1156.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.10.01</p>
                            <p class="newstitle">【2021年4月入学をご検討の皆さまへ】AO入学① エントリー期間延長</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/20/0000.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.20</p>
                            <p class="newstitle">2020 TECHNOS祭　9/20～9/22開催</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.15</p>
                            <p class="newstitle">高等教育の修学支援新制度の対象校となりました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/2056.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">日本学生支援機構奨学金二次募集のお知らせ</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/1400.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">【卒業年次在校生・保護者(保証人)の皆さまへ】在学一年延長選択制度　最終申請</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/08/03/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.08.03</p>
                            <p class="newstitle">夏季休業期間中の窓口業務について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/06/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.06</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】学生支援緊急給付金２次募集について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/01/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.01</p>
                            <p class="newstitle">オープンキャンパスに参加される皆さんへ 新型コロナウイルス感染拡大予防について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/06/15/1349.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.06.15</p>
                            <p class="newstitle">本日より新入生の分散登校が開始されました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
            
            </div>
        </div>
        <!--news_inner-->
    
    </div>

<!--SPニュース-->

<div class="foot_bnr_area">
    <!--<a href="/admission/" class="bnr ao_bnr onlySP"><img src="/new/img/header_bnr_college_sp.png" alt="まだ間に合う！大学コース"></a>-->
    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="bnr">
        <img class="onlyPC" src="/new/img/bnr_education.png" alt="高等教育の就学支援新制度の対象行となりました。">
        <img class="onlySP" src="/new/img/bnr_education_sp.png" alt="高等教育の就学支援新制度の対象行となりました。">
    </a>
</div>

    <div class="oc_btn onlySP cf">
            <p class="news_btn">NEWS</p>
            <a href="/experience/" class="oc">オープンキャンパス</a>

            <div class="news_inner">
                <div class="ttl_area">
                    <img src="/new/img/news_ttl.png" alt="NEWS">
                    <a href="/weblog/news/" class="more">NEWS一覧はこちら</a>
                    <p class="close"></p>
                </div>

                <div class="news_cont">
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/02/26/1459.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.02.26</p>
                            <p class="newstitle">【卒業生の皆さまへ】お知らせとお願い</p>
                            <p class="newstxt">
</p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1659.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【オープンキャンパス参加および学校見学ご希望の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/10/01/1156.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.10.01</p>
                            <p class="newstitle">【2021年4月入学をご検討の皆さまへ】AO入学① エントリー期間延長</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/20/0000.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.20</p>
                            <p class="newstitle">2020 TECHNOS祭　9/20～9/22開催</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.15</p>
                            <p class="newstitle">高等教育の修学支援新制度の対象校となりました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/2056.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">日本学生支援機構奨学金二次募集のお知らせ</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/1400.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">【卒業年次在校生・保護者(保証人)の皆さまへ】在学一年延長選択制度　最終申請</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/08/03/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.08.03</p>
                            <p class="newstitle">夏季休業期間中の窓口業務について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/06/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.06</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】学生支援緊急給付金２次募集について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/01/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.01</p>
                            <p class="newstitle">オープンキャンパスに参加される皆さんへ 新型コロナウイルス感染拡大予防について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/06/15/1349.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.06.15</p>
                            <p class="newstitle">本日より新入生の分散登校が開始されました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                
                </div>
            </div>
            <!--news_inner-->
        </div>
        <!--oc_btn-->


    <!---->
   <main class="manabi prag">
    <section class="intro">
        <div class="intro__inner">
            <h2><img class="onlyPC" src="/new/img/manabi/prag/mv_title.png" alt="社会で必要な力を身につける!PRAGを通した学び"><img class="onlySP" src="/new/img/manabi/prag/mv_title_sp.png" alt="社会で必要な力を身につける!PRAGを通した学び"></h2>
        </div>
    </section>

    <div class="pragMenu">
        <div class="pragMenu__block pragMenu__block--p">
            <div class="pragMenu__blockIntro">
                <p class="pragMenu__icon">身につける力</p>
                <p class="pragMenu__blockTxt">課題や目標をクリアする力</p>
            </div>
            <div class="pragMenu__blockBottom">
                <div class="pragMenu__blockWrap">
                    <p class="pragMenu__icon">学習方法</p>
                    <h2><img src="/new/img/manabi/prag/p/tit.png" alt="課題解決型学習"></h2>
                    <p class="pragMenu__blockBottomTxt">授業や多彩なイベントを通して、協働することやフィールドワークで目標達成を目指し取り組みます。</p>
                </div>
                <a class="pragMenu__btn" href="#prag_p">学びの例を見る</a>
            </div>
        </div>

        <div class="pragMenu__block pragMenu__block--r">
            <div class="pragMenu__blockIntro">
                <p class="pragMenu__icon">身につける力</p>
                <p class="pragMenu__blockTxt">専門的な知識でスキルを<br>実社会で実践する力</p>
            </div>
            <div class="pragMenu__blockBottom">
                <div class="pragMenu__blockWrap">
                    <p class="pragMenu__icon">学習方法</p>
                    <h2><img src="/new/img/manabi/prag/r/tit.png" alt="実働実践型学習"></h2>
                    <p class="pragMenu__blockBottomTxt">各学科のゼミやインターンシップを通して、職業人として必要な心構えとプロの知識を身につけます。</p>
                </div>
                <a class="pragMenu__btn" href="#prag_r">学びの例を見る</a>
            </div>
        </div>

        <div class="pragMenu__block pragMenu__block--a">
            <div class="pragMenu__blockIntro">
                <p class="pragMenu__icon">身につける力</p>
                <p class="pragMenu__blockTxt">積極的に参加し、<br>学び、挑戦する力</p>
            </div>
            <div class="pragMenu__blockBottom">
                <div class="pragMenu__blockWrap">
                    <p class="pragMenu__icon">学習方法</p>
                    <h2><img src="/new/img/manabi/prag/a/tit.png" alt="主体的参加型学習"></h2>
                    <p class="pragMenu__blockBottomTxt">「主体的に参加した」「主体的に気づき・発見を得た」「学ぶことを楽しいと思えた」この3要素を満たすテクノスの学びを大いに活用する方法です。</p>
                </div>
                <a class="pragMenu__btn" href="#prag_a">学びの例を見る</a>
            </div>
        </div>

        <div class="pragMenu__block pragMenu__block--g">
            <div class="pragMenu__blockIntro">
                <p class="pragMenu__icon">身につける力</p>
                <p class="pragMenu__blockTxt">世界に目を向け<br>世界の知恵を活かす力</p>
            </div>
            <div class="pragMenu__blockBottom">
                <div class="pragMenu__blockWrap">
                    <p class="pragMenu__icon">学習方法</p>
                    <h2><img src="/new/img/manabi/prag/g/tit.png" alt="実働実践型学習"></h2>
                    <p class="pragMenu__blockBottomTxt">常に世界の情報を意識し瞬時にアクセス。その活動と異文化を理解し、多様な価値観を知り、それらを活用するコミュニケーション能力を身につけます。</p>
                </div>
                <a class="pragMenu__btn" href="#prag_g">学びの例を見る</a>
            </div>
        </div>

        <div class="pragMenu__block pragMenu__block--other">
            <h2><img src="/new/img/manabi/prag/other/tit.png" alt="多様な学び"></h2>
            <a class="pragMenu__btn" href="#prag_other">学びの例を見る</a>
        </div>
    </div>

    <section id="prag_p" class="sec sec--p">
        <h2><img src="/new/img/manabi/prag/p/tit.png" alt="課題解決型学習"></h2>

        <div id="p_01" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>オープンキャンパス企画・運営</h3>
                <p>挑戦できる学科：全学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/p/item01/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>テクノスの強みを分析し、<br class="onlySP">魅力的に伝える方法を考える。</h4>
                    <p>テクノスのオープンキャンパスは、学生スタッフが主導して入学を希望する人に授業内容や普段の生活などについて学生ならではの情報をレクチャーしています。また、当日の運営はもちろん「プログラムの目玉」といったオープンキャンパスそのものの企画にも挑戦。これらは現実の社会に通じる課題解決力や実践力を磨くことにも役立ちます。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/p/item01/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/p/item01/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5>オープンキャンパススタッフに<br>参加するメリットは?</h5>
                            <p>自分が所属する学科だけではなく、学院全体を俯瞰して見ることができます。そのため、自分自身があらゆることに挑戦したいと思える気持ちが芽生えること、学科を越えた学生や教員とのつながりができることをはじめ、人に対して短い言葉で明確に伝えるコミュニケーション力も養われます。</p>
                        </div>
                        <img class="sec__itemBottomIcon" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div id="p_02" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>TECHNOS祭<small>(学園祭)</small></h3>
                <p>挑戦できる学科：全学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/p/item02/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>仲間とともに考えつくりあげる。<br class="onlySP">地域に開かれた学院祭を運営。</h4>
                    <p>秋に開催される「TECHNOS祭」は、テクノス全体でつくりあげるイベント。学生たちが企画から運営まですべてを手がけています。学科の垣根を越えた組織の中で、協働作業によってイベントを成功に導きます。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/p/item02/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/p/item02/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5 class="line2">運営組織の役割は?</h5>
                            <p>大規模なイベントを開催するため幅広い役割担当に分かれています。どんなアーティストを呼ぶか、来校者をどう増やすか、予算内で運営するための施策など社会に出て役立つことが学べます。</p>
                        </div>
                        <div class="sec__itemBottomTxt">
                            <h5>運営組織に<br class="onlyPC">参加するメリットは?</h5>
                            <p>イベントは企画から準備までのプロセスが特に大変ですが、それだけにやり遂げた時の達成感はとても大きいのが特長です。また、学科・コースを越えた学生たちとの交流はとても貴重なもの。卒業しても付き合える仲間と出会えます!</p>
                        </div>
                        <img class="sec__itemBottomIcon center" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="prag_r" class="sec sec--r">
        <h2><img src="/new/img/manabi/prag/r/tit.png" alt="実働実践型学習"></h2>

        <div id="r_01" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>シヴィルマリッジProject</h3>
                <p>挑戦できる学科：<br class="onlySP">ブライダル科／ホテル科／芸術・エンターテイメント系学科／芸術・クリエーター系学科<br class="onlyPC"><span class="onlySP">/</span>観光旅行科／こども学科／スポーツビジネス科／建築学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/r/item01/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>本物の結婚式をプロデュース。<br class="onlySP">演出運営も自らの手で!</h4>
                    <p>シヴィルマリッジ(市民結婚式)とは、市町村など公的機関が認可した場所で行う、近年注目を集めている結婚式。2019年からスタートしたこのプロジェクトは、挙式内容の企画提案、段取り、当日の運営すべてを学生たちが担い、実際に式を挙げたカップルからも感謝の言葉をいただきました。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/r/item01/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/r/item01/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5>成功につなげるポイントは?</h5>
                            <p>「どんなウェディングを実現したいか」、新郎・新婦のニーズやご意見をもとにしっかりと話し合うことが大切です。その後、準備期間では一人ひとりが任された役割を認識し、「これなら何があっても大丈夫!」という自信を持って当日に臨もう。</p>
                        </div>
                        <img class="sec__itemBottomIcon onlyPC" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                    </div>
                </div>
                <div class="sec__itemBottom--interview">
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomImg"><img src="/new/img/manabi/prag/r/item01/photo02.jpg" alt=""></div>
                        <div class="sec__itemBottomTxt">
                            <div class="sec__itemBottomTxt--tit">
                                <h5>社会に出る前に本物の<br class="onlySP">結婚式に<br class="onlyPC">携われたのが、<br class="onlySP">とても貴重な<br class="onlySP">経験となりました。</h5>
                                <p>シヴィルマリッジProject<br class="onlySP">リーダー　<br class="onlySP"><span>小座間 恵</span>さん</p>
                            </div>
                            <p>1年生の時に模擬挙式を行うのですが、シヴィルマリッジProjectでは、模擬挙式では味わうことが出来ないほどの責任の重圧を感じました。カップルにとって一生に一度の結婚式を「学生だから」で、失敗してはいけない。プロ同等より、プロ以上の気持ちを込めて、成功させる必要がありました。そのためには、チームを動かす力やチームをまとめる力、考えて行動する力など、学校で習った能力をフル活用し、絶対にシヴィルマリッジProjectを成功させるという覚悟が必要だと思いました。社会に出る前に本物の結婚式に携われたことは、大きな自信につながりました。</p>
                        </div>
                        <img class="sec__itemBottomIcon onlySP" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div id="r_02" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>地域のムービー制作</h3>
                <p>挑戦できる学科：<br class="onlySP">放送芸術科／ミュージック科／声優・演劇科／音響芸術科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/r/item02/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>小金井市の魅力を<br class="onlySP">ふんだんに伝えるPV制作。</h4>
                    <p>小金井市市制60周年を記念した、小金井市の魅力を世界へ発信する広報ムービーを学生たちが制作。監督、撮影、音声、照明、編集のみならず、出演者にもテクノス生が参加。ほかにも国分寺市や東京消防庁などのムービーも制作しています。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomWrap .over">
                        <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/r/item02/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/r/item02/img_sp.png" alt=""></div>
                        <img class="sec__itemBottomIcon" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="prag_a" class="sec sec--a">
        <h2><img src="/new/img/manabi/prag/a/tit.png" alt="主体的参加型学習"></h2>

        <div id="a_01" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>MUSAKO FEST<small>(ムサコフェスト)</small></h3>
                <p>挑戦できる学科：<br class="onlySP">芸術・エンターテイメント系学科／建築学科／芸術・クリエーター系学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/a/item01/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>中・高校生と感動を生み出す<br class="onlySP">夏の3days。</h4>
                    <p>テクノスの学生を中心に、中・高校生も交えた「MUSAKO FEST」。フェスの企画やアーティストの出演交渉、当日のステージ設営、ライブ中継まで学科を横断して協働しながら作り上げていきます。天候不良といった予想外のトラブルも貴重な体験のひとつです。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/a/item01/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/a/item01/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5>成功につなげるポイントは?</h5>
                            <p>悪天候や機械トラブルなど、フェス当日は予想外なことが起きる可能性も。常に冷静に対処しながらも、スピード感を持って連携して乗り切るのがコツです。</p>
                        </div>
                        <img class="sec__itemBottomIcon center" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div id="a_02" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>アスレティック<br class="onlySP">トレーナー研修<small>&ensp;ホープ大学</small></h3>
                <p>挑戦できる学科：スポーツビジネス科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/a/item02/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>スポーツ大国アメリカの<br class="onlySP">トレーナー育成現場に飛び込む。</h4>
                    <p>テクノスの姉妹校であるアメリカ・ミシガン州にあるホープ大学。約2週間におよぶ留学期間中は語学やトレーナーについての講義はもちろん、現地学生とのディスカッションなど濃密な時間を過ごします。帰国後は、渡米前に設けられた課題について発表します。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/a/item02/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/a/item02/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5 class="line2">なぜアメリカで学ぶの?</h5>
                            <p>日本ではまだアスレティックトレーナーの公的な資格はありませんが、さまざまなプロスポーツが発展しているアメリカでは、アスレティックトレーナーに対する大学での学びや職業が確立しています。人体構造や生理学など医学的知識をもとにした本格的な知識を身につけることができます。</p>
                        </div>
                    <img class="sec__itemBottomIcon center" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div id="a_03" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>経営学<small>&ensp;仮想会社の設立</small></h3>
                <p>挑戦できる学科：ホテル科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/a/item03/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>仮想会社を設立。<br class="onlySP">学生の手による店舗経営を実践する。</h4>
                    <p>TECHNOS祭の模擬店営業に向けて仮想会社を設立し、事業計画や商品開発、ブランド戦略、広報・営業活動などを行います。TECHNOS祭後は、収支報告会も実施し、どのくらいの収入と支出があり、利益はいくら出たのかなど、決算結果を明らかにして今後の目標を立てます。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/a/item03/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/a/item03/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5>なぜ黒字にならないといけないの?</h5>
                            <p>会社は利益を出さなければ赤字となり、借金をしなければ従業員などの給与や材料調達、加工といった原価を払うことができなくなることから、経営者には黒字にする(利益を生み出す)ことが求められています。そのためにも、計画段階においてしっかりとした事業の方向性や、綿密な市場調査が重要です。</p>
                        </div>
                        <img class="sec__itemBottomIcon center" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div id="a_04" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>接客表現力<small>&ensp;ナレーション授業</small></h3>
                <p>挑戦できる学科：<br class="onlySP">ホテル科／エアライン科／鉄道交通科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/a/item04/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>全身を使った表現力を身につける。</h4>
                    <p>表現力を高めることを目的としたエアトラの学生を中心とした「ナレーション」の実務演習授業。役を演じることを経験することで、人前で堂々と話せる自信や仲間と協働するチームワークを身につけます。あらゆる仕事の接客スキルにも活かせる表現力を高めていきます。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/a/item04/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/a/item04/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5>どうして接客業に使える<br class="onlySP">スキルなの?</h5>
                            <p>飲食業、販売業、観光・交通業など、どんな業界であっても、人と人が面と向かってコミュニケーションをとるのが接客業の仕事です。その人のコミュニケーションスキルによって「商品がより販売できた」「お客さまから信頼された」などの成果につながります。ナレーションの授業は、人とコミュニケーションするための自信をつけることが目的です。</p>
                        </div>
                        <img class="sec__itemBottomIcon center" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="prag_g" class="sec sec--g">
        <h2><img src="/new/img/manabi/prag/g/tit.png" alt="実働実践型学習"></h2>

        <div id="g_01" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>インターナショナルウィーク</h3>
                <p>挑戦できる学科：全学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/g/item01/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>世界の学生たちと交流する<br class="onlySP">テクノス最大のイベント。</h4>
                    <p>毎年6月に2週間開催される国際交流イベント。イギリス オックスフォード大学をはじめ、アメリカ8校、ニュージーランド、台湾などの大学教授や学生たちがテクノスカレッジに滞在します。今年度は「Only one world」をテーマにSDGsを柱としたプログラムで構成され、国や地域などの境界を越えた新しい学びを創出します。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/g/item01/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/g/item01/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5>ホームステイを希望する<br class="onlySP">海外の学生も</h5>
                            <p>インターナショナルウィーク中、日本でのホームステイを希望する海外の学生もいます。そこで、ご自宅をホームステイ先にしても良いという方がいれば、保護者の了解を取った上で運営本部までご連絡ください。</p>
                        </div>
                        <img class="sec__itemBottomIcon center" src="/new/img/manabi/prag/sec_common_img02.png" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div id="g_02" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>Technos Art Program</h3>
                <p>挑戦できる学科：<br class="onlySP">芸術・エンターテイメント系学科／芸術・クリエーター系学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/g/item02/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>NYと東京を結び、<br class="onlySP">芸術に触れながら交流を深める。</h4>
                    <p>姉妹校の一つであるニューヨーク州立大学パーチェス校との交流プログラム。エンターテイメント、アートの本場NYを肌で感じながらクリエイティブの刺激を受けることを目的としています。また、パーチェス校の学生や教授もTECHNOS 祭に合わせて来日するなど、相互の人的交流を深めます。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/g/item02/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/g/item02/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5 class="line2">長期留学のきっかけにも。</h5>
                            <p>「Technos Art Program」をきっかけに、ニューヨーク州立大学パーチェス校に長期留学する道もあります。テクノスを1年間休学して、1年におよぶ長期留学をしている学生もいます。</p>
                        </div>
                    <img class="sec__itemBottomIcon center" src="/new/img/manabi/prag/sec_common_img02.png" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div id="g_03" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>サンドイッチ留学制度</h3>
                <p>挑戦できる学科：全学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/g/item03/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>1年間休学して留学へ。<br class="onlySP">テクノス独自の留学制度。</h4>
                    <p>テクノスを1年間休学して、海外の教育機関に長期間留学します。行きたい国や期間は自分で自由に設定でき、日本を離れた場所で外国人に囲まれながら生活し、海外の授業を受けることで外国語によるコミュニケーション力や論理的思考などを高めることができます。入学後からガイダンスや個別カウンセリングを実施します。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomWrap textRight">
                        <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/g/item03/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/g/item03/img_sp.png" alt=""></div>
                        <div class="textRight__inner">
                            <div class="sec__itemBottomTxt">
                                <h5>どんなスケジュールなの?</h5>
                                <p>1年次の6～8月にサンドイッチ留学のガイダンスを行い、9月から始まる個別カウンセリングで留学先を決定します。その後、2年次の4月からテクノスを1年間休学し、留学先での1年間におよぶ生活が始まります。そして、帰国後は2年次に復学すると同時に、就職活動を開始します。</p>
                            </div>
                            <img class="sec__itemBottomIcon" src="/new/img/manabi/prag/sec_common_img02.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="prag_other" class="sec sec--other">
        <h2><img src="/new/img/manabi/prag/other/tit.png" alt="多様な学び"></h2>

        <div id="other_01" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>インターンシップ</h3>
                <p>挑戦できる学科：全学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/other/item01/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>プロの仕事を肌で感じる。</h4>
                    <p>プロが働く現場で仕事のノウハウを学び、現場が求める力を身につけます。海外ホテルでのインターンシップでは、グローバル時代に活躍するための語学力と働く力の両方を磨き、幅広い視野を養います。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/other/item01/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/other/item01/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5>どんな提携先が<br class="onlyPC">あるの?</h5>
                            <p>帝国ホテル、中国東方航空、アシアナ航空、八芳園、曽我、東京メトロなどをはじめ、業界で名高い制作プロダクションやイベント会社、地域の保育園など多数あります。</p>
                        </div>
                        <div class="sec__itemBottomTxt">
                            <h5>連携企業のほかにも<br class="onlyPC">参加できるの?</h5>
                            <p>就職活動に役立ててもらおうと、あらゆる企業でインターンシップは開催されています。書類審査・面接といった条件を設けている企業もありますので、クラス担任かキャリアサポートスタッフにご相談ください。</p>
                        </div>
                        <img class="sec__itemBottomIcon center" src="/new/img/manabi/prag/sec_common_img02.png" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div id="other_02" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>施設交流や地域イベントへの参加</h3>
                <p>挑戦できる学科：全学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/other/item02/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>シルバー世代の健康づくりや<br class="onlySP">地域イベントを盛り上げる。</h4>
                    <p>介護老人保健施設「あんず苑」の利用者や、地域住民をキャンパスに招いた交流会を設け、学生自らが小金井さくら体操や各種レクリエーション活動を行い、地域住民の健康促進の一助を担います。また、「小金井なかよし市民まつり」といったイベントにも積極的に参加し、地域を盛り上げています。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/other/item02/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/other/item02/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5>地域イベントに参加する<br class="onlySP">メリットは?</h5>
                            <p>学内で催すイベントと比べて、地域イベントに訪れる方は一般の方ばかり。自分が学んだことが社会で通用するか見極めるいいきっかけとなります。また、運営者である社会人の方との協働作業は、社会を知る上でも貴重な機会となるはずです。</p>
                        </div>
                        <img class="sec__itemBottomIcon center" src="/new/img/manabi/prag/sec_common_img02.png" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div id="other_03" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>テクノスアカデミー</h3>
                <p>挑戦できる学科：<br class="onlySP">スポーツビジネス科／幼児教育学科／こども学科／教育専攻科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/other/item03/photo.jpg" alt=""></div>
                <div class="sec__itemWrap">
                    <div class="sec__itemTxt">
                        <h4>学びの成果を子どもたちの<br class="onlySP">教育に活かす。</h4>
                        <p>学んだ専門知識や技術を子どもたちに楽しく教える「テクノスアカデミー」は地域の方との交流機会になっています。キャンパス内にある「テクノスポ一ツクラブ」で子どもに向けたスイミングとサッカーの指導も実施。</p>
                    </div>
                    <img class="sec__itemBottomIcon" src="/new/img/manabi/prag/sec_common_img02.png" alt="">
                </div>
            </div>
        </div>

        <div id="other_04" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>TEC<small>(テクノスイングリッシュクラブ)</small></h3>
                <p>挑戦できる学科：全学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/other/item04/photo.jpg" alt=""></div>
                <div class="sec__itemWrap">
                    <div class="sec__itemTxt">
                        <h4>好きなだけ英語を話せる・<br class="onlySP">活用できる場を<br class="onlyPC">キャンパス内に。</h4>
                        <p>海外姉妹校の卒業生がティーチングアシスタントとして常駐しているSkill up room。キャンパス内に英語でコミュニケーションする場として多くの学生が利用しています。また、海外の伝統行事を体験しながら英語に親しむこともできます。</p>
                    </div>
                    <img class="sec__itemBottomIcon" src="/new/img/manabi/prag/sec_common_img02.png" alt="">
                </div>
            </div>
        </div>

        <div id="other_05" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>きしゃぽっぽ保育園での英会話</h3>
                <p>挑戦できる学科：英語キャリア科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/other/item05/photo.jpg" alt=""></div>
                <div class="sec__itemWrap">
                    <div class="sec__itemTxt">
                        <h4>英語を話す楽しさを<br class="onlySP">子どもたちに教える。</h4>
                        <p>キャンパス内にある「東京工学院きしゃぽっぽ保育園」は、保育実習先以外にも、英語を学ぶ学生が英語教育を実践する場としても活用されています。子どもたちが楽しんで学べるようみんなで内容を作り上げていきます。</p>
                    </div>
                    <img class="sec__itemBottomIcon" src="/new/img/manabi/prag/sec_common_img02.png" alt="">
                </div>
            </div>
        </div>

        <div id="other_06" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>鉄道会社のインターンシップ</h3>
                <p>挑戦できる学科：鉄道交通科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/other/item06/photo.jpg" alt=""></div>
                <div class="sec__itemWrap">
                    <div class="sec__itemTxt">
                        <h4>安全な運行を支える鉄道の現場を体験。</h4>
                        <p>鉄道交通科では、東京メトロの協力のもと、登校前の時間を有効活用した早朝インターンシップを行っています。実際の地下鉄ホームに立ち、乗り換えのご案内やトラブル対応などに対処。安全輸送の重要性や、お客さまに対する細やかな気遣いなどの大切さを学びます。</p>
                    </div>
                    <img class="sec__itemBottomIcon" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                </div>
            </div>
        </div>

        <div id="other_07" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>テクノスツーリスト</h3>
                <p>挑戦できる学科：観光旅行科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/other/item07/photo.jpg" alt=""></div>
                <div class="sec__itemWrap">
                    <div class="sec__itemTxt">
                        <h4>キャンパス内で一般向けの<br class="onlySP">旅行商品を販売。</h4>
                        <p>2018年に学内にグランドオープンした「テクノスツーリスト」は、一般の方向けに実際の旅行商品を販売。観光案内、ツアーの提案、航空チケット、ホテルの手配など、カウンター業務を行いながら、学んだ観光知識やホスピタリティサービスを実践します。</p>
                    </div>
                    <img class="sec__itemBottomIcon" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                </div>
            </div>
        </div>

        <div id="other_08" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>日帰りバスツアー企画コンテスト</h3>
                <p>挑戦できる学科：観光旅行科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/other/item08/photo.jpg" alt=""></div>
                <div class="sec__itemWrap">
                    <div class="sec__itemTxt">
                        <h4 class="wide">オリジナル企画を競い、<br class="onlySP">本物のツアーを実現。</h4>
                        <p>エアトラの観光旅行科と鉄道交通科のコラボコンテスト。学生がオリジナルツアーを考え、アイデアを競い合います。コンテストに優勝すると、テクノスツーリストにて実際のツアーが実現します。</p>
                    </div>
                    <img class="sec__itemBottomIcon" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                </div>
            </div>
        </div>

        <div id="other_09" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>アニメーション制作<small>&ensp;コラボ授業</small></h3>
                <p>挑戦できる学科：<br class="onlySP">アニメーション科／声優・演劇科／音響芸術科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/other/item09/photo.jpg" alt=""></div>
                <div class="sec__itemWrap">
                    <div class="sec__itemTxt">
                        <h4 class="wide">一つのアニメーション作品に<br class="onlySP">学生の力が集結。</h4>
                        <p>アニメーション科が制作する作品では、声優・演劇科の学生がアフレコを担当し、音響芸術科が音声収録を協力するなど、学科の垣根を越えた協働授業が行われています。完成した作品は、TECHNOS祭や卒業制作などで公開されます。</p>
                    </div>
                    <img class="sec__itemBottomIcon" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                </div>
            </div>
        </div>

        <div id="other_10" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>Inter FM 897<br class="onlySP"><small>「TECHNOS COLLEGE Young Blood」</small></h3>
                <p>挑戦できる学科：全学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/other/item10/photo.jpg" alt=""></div>
                <div class="sec__itemWrap">
                    <div class="sec__itemTxt">
                        <h4>学内で公開収録。プロと共に番組制作。</h4>
                        <p>定期的に一回、学内で公開収録されているFMラジオ番組は、学生が企画提案や当日の進行などを担当。DJはタレントのユージさん。自分たちが中心となって考えた企画を、ラジオを通してリスナーが視聴します。今年度は、学外での公開収録も予定しています。</p>
                    </div>
                    <img class="sec__itemBottomIcon" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                </div>
            </div>
        </div>

        <div id="other_11" class="sec__item">
            <div class="sec__itemTit ac_btn">
                <h3>オープン・ラボ</h3>
                <p>挑戦できる学科：全学科</p>
            </div>
            <div class="sec__itemBox ac_content">
                <div class="sec__itemImg"><img src="/new/img/manabi/prag/other/item11/photo.jpg" alt=""></div>
                <div class="sec__itemTxt">
                    <h4>卒業生や社会人も参加できる<br class="onlySP">自由なラボで、新たな価値を創出。</h4>
                    <p>今年度から新たに設置されたのが「オープン・ラボ」です。TECHNOSゼミ等のさまざまなプロジェクト活動に使えるラボでプレゼンの場など、活発な議論を交わすことのできる空間です。</p>
                </div>
                <div class="sec__itemBottom">
                    <div class="sec__itemBottomImg"><img class="onlyPC" src="/new/img/manabi/prag/other/item11/img.png" alt=""><img class="onlySP" src="/new/img/manabi/prag/other/item11/img_sp.png" alt=""></div>
                    <div class="sec__itemBottomWrap">
                        <div class="sec__itemBottomTxt">
                            <h5>プロジェクト活動は<br class="onlyPC">どのように進めるの?</h5>
                            <p>プロジェクト活動は、解決が求められた問題(テーマ)について、チームで協働し解決策を検討します。適切な情報収集と活用(情報リテラシー)により解決策をまとめ、依頼者にプレゼンテーションします。</p>
                        </div>
                        <div class="sec__itemBottomTxt">
                            <h5 class="line2">どう役立つの?</h5>
                            <p>オープン・ラボで取り組んだ成果は、在学中に自らが成し遂げた証。専門的な知識や技術を実際に活かした経験は就職活動などの場でアピールすることができます。</p>
                        </div>
                        <img class="sec__itemBottomIcon center" src="/new/img/manabi/prag/sec_common_img.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>


    <div class="bottomBtn">
        <ul>
            <li><a href="/manabi/seminar.php">TECHNOSゼミ</a></li>
            <li><a href="/manabi/career.php">キャリア支援プログラム</a></li>
        </ul>
    </div>

    <div id="tab" class="menu">
        <div class="menu__content">
            <ul class="menu__contentTabmenu">
                <li class="menu__contentTabmenuBtn eng tabLabel on">東京工学院専門学校</li>
                <li class="menu__contentTabmenuBtn air tabLabel">東京エアトラベル・<br class="onlySP">ホテル専門学校</li>
            </ul>

            <div class="menu__contentTab eng tabPanel on">
                <div class="menu__contentTabInner">
                    <ul>
                        <li><a href="/eng/art/concert/"><img src="/new/img/experience/online/eng/menu_img01_off.jpg" alt="コンサート・イベント科"></a></li>
                        <li><a href="/eng/art/art/"><img src="/new/img/experience/online/eng/menu_img02_off.jpg" alt="音響芸術科"></a></li>
                        <li><a href="/eng/art/image/"><img src="/new/img/experience/online/eng/menu_img03_off.jpg" alt="放送芸術科"></a></li>
                        <li><a href="/eng/art/musician/"><img src="/new/img/experience/online/eng/menu_img04_off.jpg" alt="ミュージック科"></a></li>
                        <li><a href="/eng/art/play/"><img src="/new/img/experience/online/eng/menu_img05_off.jpg" alt="声優・演劇科"></a></li>
                        <li><a href="/eng/creator/game/"><img src="/new/img/experience/online/eng/menu_img06_off.jpg" alt="ゲームクリエーター科"></a></li>
                        <li><a href="/eng/creator/cg/"><img src="/new/img/experience/online/eng/menu_img07_off.jpg" alt="CGクリエーター科"></a></li>
                        <li><a href="/eng/creator/web/"><img src="/new/img/experience/online/eng/menu_img08_off.jpg" alt="Webデザイン科"></a></li>
                        <li><a href="/eng/creator/cartoon/"><img src="/new/img/experience/online/eng/menu_img09_off.jpg" alt="マンガ科"></a></li>
                        <li><a href="/eng/creator/animation/"><img src="/new/img/experience/online/eng/menu_img10_off.jpg" alt="アニメーション科"></a></li>
                        <li><a href="/eng/creator/graphic/"><img src="/new/img/experience/online/eng/menu_img11_off.jpg" alt="グラフィックデザイン科"></a></li>
                        <li><a href="/eng/edu/sportsbusiness/"><img src="/new/img/experience/online/eng/menu_img12_off.jpg" alt="スポーツビジネス科"></a></li>
                        <li><a href="/eng/edu/kinder/"><img src="/new/img/experience/online/eng/menu_img13_off.jpg" alt="幼児教育学科"></a></li>
                        <li><a href="/eng/edu/child/"><img src="/new/img/experience/online/eng/menu_img14_off.jpg" alt="こども学科"></a></li>
                        <li><a href="/eng/edu/official/"><img src="/new/img/experience/online/eng/menu_img15_off.jpg" alt="公務員科"></a></li>
                        <li><a href="/eng/eng/archi/"><img src="/new/img/experience/online/eng/menu_img16_off.jpg" alt="建築学科"></a></li>
                        <li><a href="/eng/eng/interior/"><img src="/new/img/experience/online/eng/menu_img17_off.jpg" alt="インテリアデザイン科"></a></li>
                        <li><a href="/eng/eng/it_senmon/"><img src="/new/img/experience/online/eng/menu_img18_off.jpg" alt="情報システム科"></a></li>
                        <li><a href="/eng/eng/electric/"><img src="/new/img/experience/online/eng/menu_img19_off.jpg" alt="電気電子学科"></a></li>
                        <li><a href="/eng/eng/aerial/"><img src="/new/img/experience/online/eng/menu_img20_off.jpg" alt="航空学科"></a></li>
                        <li><a href="/eng/college/w_school/"><img src="/new/img/experience/online/eng/menu_img21_off.jpg" alt="大学併修学科"></a></li>
                        <li><a href="/eng/college/edupro/"><img src="/new/img/experience/online/eng/menu_img22_off.jpg" alt="教育専攻科"></a></li>
                        <li><a href="/eng/college/law/"><img src="/new/img/experience/online/eng/menu_img23_off.jpg" alt="法律情報科"></a></li>
                        <li><a href="/eng/college/business/"><img src="/new/img/experience/online/eng/menu_img24_off.jpg" alt="経営情報科"></a></li>
                        <li><a href="/eng/research/"><img src="/new/img/experience/online/eng/menu_img25_off.jpg" alt="研究科"></a></li>
                    </ul>
                </div>
            </div><!-- tab end -->

            <div class="menu__contentTab tabPanel air">
                <div class="menu__contentTabInner">
                    <ul>
                        <li><a href="/air/airline/"><img src="/new/img/experience/online/air/menu_img01_off.jpg" alt="エアライン科"></a></li>
                        <li><a href="/air/airportservice/"><img src="/new/img/experience/online/air/menu_img02_off.jpg" alt="エアポートサービス科"></a></li>
                        <li><a href="/air/english/"><img src="/new/img/experience/online/air/menu_img03_off.jpg" alt="英語キャリア科"></a></li>
                        <li><a href="/air/hotel/"><img src="/new/img/experience/online/air/menu_img04_off.jpg" alt="ホテル科"></a></li>
                        <li><a href="/air/bridal/"><img src="/new/img/experience/online/air/menu_img05_off.jpg" alt="ブライダル科"></a></li>
                        <li><a href="/air/bizsecretary/"><img src="/new/img/experience/online/air/menu_img06_off.jpg" alt="ビジネスマナー・秘書科"></a></li>
                        <li><a href="/air/travel/"><img src="/new/img/experience/online/air/menu_img07_off.jpg" alt="観光旅行科"></a></li>
                        <li><a href="/air/train/"><img src="/new/img/experience/online/air/menu_img08_off.jpg" alt="鉄道交通科"></a></li>
                        <li><a href="/air/college/"><img src="/new/img/experience/online/air/menu_img09_off.jpg" alt="大学併修科"></a></li>
                        <li><a href="/air/graduate"><img src="/new/img/experience/online/air/menu_img10_off.jpg" alt="研究科"></a></li>
                    </ul>
                </div>
            </div><!-- tab end -->
        </div>
    </div>

</main>
   <!--/footer-->
    <footer>
    	<div class="inner">
            <p>お電話でのご相談や資料請求・来校のご予約はこちらまで</p>
            <div class="cf">
                <dl>
                    <dt>東京工学院専門学校</dt>
                    <dd><img src="/new/img/kogyo_tel.png" alt="0120-634-200"></dd>
                </dl>
                <dl>
                    <dt>東京エアトラベル・ホテル専門学校</dt>
                    <dd><img src="/new/img/air_tel.png" alt="0120-634-300"></dd>
                </dl>
            </div>

            <div class="add cf">
                <div class="logo">
                <a href="/"><img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a>
                    <p>総合学院テクノスカレッジ</p>
                </div>
                <div class="add_box">
                    <p>府中・小金井インテリジェントキャンパス ： <br class="onlySP">〒184-8543 東京都小金井市前原町5-1-29</p>
                    <p>渋谷サテライトキャンパス ： <br class="onlySP">〒151-0051 東京都渋谷区千駄ケ谷5-30-16</p>
                </div>
                    
                <div class="footerMenu">
                    <a href="/privacypolicy.php">プライバシーポリシー</a>
                </div>
            
            </div>

            <p class="copyright">Copyright © Technos College. All Rights Reserved.</p>
        </div>

        <p id="gotop"><img src="/new/img/gotop.png" alt="gotop"></p>
    </footer>
    <!--footer/-->


</div><!--wrapper/-->

<script type="text/javascript" class="microad_blade_track">
<!--
var microad_blade_jp = microad_blade_jp || { 'params' : new Array(), 'complete_map' : new Object() };
(function() {
var param = {'co_account_id' : '24', 'group_id' : '', 'country_id' : '1', 'ver' : '2.1.0'};

var param_custom =
{
"set_1": {
"item" : "rsnemibl20160805079",
}
}
param.custom = param_custom;

microad_blade_jp.params.push(param);

var src = (location.protocol == 'https:')
? 'https://d-track.send.microad.jp/js/blade_track_jp.js' : 'http://d-cache.microad.jp/js/blade_track_jp.js';

var bs = document.createElement('script');
bs.type = 'text/javascript'; bs.async = true;
bs.charset = 'utf-8'; bs.src = src;

var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(bs, s);
})();
-->
</script>

<!-- add. 0909 recruit -->
<script type="text/javascript" class="microad_blade_track">
<!--
var microad_blade_jp = microad_blade_jp || { 'params' : new Array(), 'complete_map' : new Object() };
(function() {
var param = {'co_account_id' : '24', 'group_id' : '', 'country_id' : '1', 'ver' : '2.1.0'};
microad_blade_jp.params.push(param);

var src = (location.protocol == 'https:')
? 'https://d-track.send.microad.jp/js/blade_track_jp.js' : 'http://d-cache.microad.jp/js/blade_track_jp.js';

var bs = document.createElement('script');
bs.type = 'text/javascript'; bs.async = true;
bs.charset = 'utf-8'; bs.src = src;

var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(bs, s);
})();
-->
</script>


</body>
</html>


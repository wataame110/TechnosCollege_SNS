<!DOCTYPE html>
<html lang="ja">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AO入学 | 東京工学院専門学校 / 東京エアトラベル・ホテル専門学校</title>
    <meta name="keywords" content="AO入学総合学院テクノスカレッジ,東京工学院専門学校,東京エアトラベル・ホテル専門学校" />
    <meta name="description" content="" />
    <meta name="format-detection" content="telephone=no">
    <link rel="canonical" href="" />
    <link rel="shortcut icon" type="image/x-icon" href="/lib/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

<script type="text/javascript" src="//www2.infoclipper.net/infohp_js/751c6lf.js" charset="UTF-8"></script>
<script type="text/javascript" src="//www2.infoclipper.net/infohp_js/fpAnalysis.js" charset="UTF-8"></script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NF9PB6Z');</script>
<!-- End Google Tag Manager -->
    <!--CSS File-->
    <link rel="stylesheet" type="text/css" href="/new/css/reset.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/common.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/new/css/pc_style.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/sp_style.css" media="screen,print">

    <!--TOP CSS-->
<link rel="stylesheet" type="text/css" href="/new/css/admission/pc_style.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/admission/sp_style.css" media="screen,print">


    
    
    <link rel="stylesheet" type="text/css" href="/new/css/slick.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/slick-theme.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/experience/common.css" media="screen,print">
    

    <!--JS File-->
    <script type="text/javascript" src="/new/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/new/js/jquery.matchHeight.js"></script>
    <script type="text/javascript" src="/new/js/jquery.inview.js"></script>
<script type="text/javascript" src="/new/js/custom.js"></script>
<script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script>

    <!--<script type="text/javascript" src="/new/js/jquery.bxslider.min.js"></script>-->

    
    
    
<script type="text/javascript" src="/lib/js/ga.js"></script>
</head>
<body >
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NF9PB6Z"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="fakeLoader"></div>
<div class="wrapper">
    

    <!--/header-->
    <header>
        <div class="inner cf onlyPC">
            <div class="h1_box">
                <a href="/"><h1>総合学院テクノスカレッジ</h1>
            <img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a>    
            </div>
        
            <nav>
            <!--<a href="/admission/" class="bnr"><img src="/new/img/header_bnr_college.png" alt="まだ間に合う！大学コース"></a>-->
                <div class="sns">
                <a href="/experience/" class="oc_btn_head">オープンキャンパス</a>
                    <ul>
                        <li><a href="https://technosac.jp/weblog/" target="_blank">テクノスブログ</a></li>
                    </ul>
                </div>


                <div class="main_menu">
                    <ul class="mainlist">
                        <li><a href="/eng/">東京工学院専門学校</a></li>
                        <li><a href="/air/">東京エアトラベル・ホテル<br />専門学校</a></li>
                        <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1" target="_blank">資料請求</a></li>
                        <li><a href="/access.php">アクセス</a></li>
                        <li><a class="menu_btn"><span class="menu_btn-icon"></span>MENU</a></li>
                    </ul>

                    <div class="nav_inner cf">
                        <dl class="menulist">
                            <dt><a href="/admission/">入学のご案内</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/admission/">募集要項・学費・奨学金</a></li>
                                    <li><a href="/admission/admission.php">入学までの流れ</a></li>
                                    <li><a href="/admission/selection.php">選考方法</a></li>
                                    <li><a href="/admission/ao.php">AO入学</a></li>
                                    <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker01">各種奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
                                    <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <dl class="menulist">
                            <dt><a href="/school/">学院案内／教育理念</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/school/greetings.php#unker02">理事長挨拶</a></li>
                                    <li><a href="/school/greetings.php#unker01">建学の精神</a></li>
                                    <li><a href="/school/greetings.php#unker04">沿革</a></li>
                                    <li><a href="/school/greetings.php#unker03">学院長挨拶</a></li>
                                <li><a href="/school/greetings.php/#unker05">情報公開</a></li>
                                </ul>
                            </dd>
                            <dt><a href="/campus/">キャンパスライフ</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/campus/facilities.php">施設紹介</a></li>
                                    <li><a href="/campus/club.php">部活・クラブ紹介</a></li>
                                    <li><a href="/campus/internationalweek.php">インターナショナルウィーク</a></li>
                                    <li><a href="/campus/twinneduniv.php">海外姉妹校の紹介</a></li>
                                <li><a href="/campus/sandwich-study-abroad.php">サンドイッチ留学</a></li>
                                    <li><a href="/campus/eng-year-event.php">東京工学院専門学校 年間イベント</a></li>
                                    <li><a href="/campus/air-year-event.php">東京エアトラベル・ホテル専門学校 年間イベント</a></li>
                                </ul>
                            </dd>
                            <dt>就職への取り組み</dt>
                            <dd>
                                <ul>
                                    <li><a href="/manabi/career.php">キャリア支援プログラム</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <ul class="link_list">
                            <li><a href="/eng/">東京工学院専門学校</a></li>
                            <li><a href="/air/">東京エアトラベル・ホテル専門学校</a></li>
                        <li><a href="/manabi/prag.php">PRAGについて</a></li>
                        <li><a href="/manabi/seminar.php">TECHNOS ゼミについて</a></li>
                            <li><a href="/school/collagecourse.php">大学コース</a></li>
                            <li><a href="/experience/">オープンキャンパス</a></li>
                            <li><a href="/access.php">アクセス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1">資料請求</a></li>
                            <li><a href="/forobog.php">卒業生の皆さまへ</a></li>
                            <li><a href="/school/parent.php">保護者の皆さまへ</a></li>
                            <li><a href="/carriercanter/carriercanter.php">企業の皆さまへ</a></li>
                            <li><a href="/inquiry.php">お問い合わせ</a></li>
                            <li><a href="/faq.php">Q&amp;A</a></li>
                        <li class="middle"><a href="https://technosac.jp/weblog/" target="_blank">テクノスブログ</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

        <div class="onlySP">
            <ul class="main_nav cf">
                <li><a href="/"><img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a></li>
                <li><a href="/eng/"><img src="/new/img/sp_menu01.png" alt="東京工学院専門学校"></a></li>
                <li><a href="/air/"><img src="/new/img/sp_menu02.png" alt="東京エアトラベル・ホテル専門学校"></a></li>
                <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1"><img src="/new/img/sp_menu03.png" alt="資料請求"></a></li>
                <li><a href="/access.php"><img src="/new/img/sp_menu04.png" alt="アクセス"></a></li>
                <li><a class="menu_btn"><span class="menu_btn-icon"></span><p>MENU</p></a></li>
            </ul>

            <div class="nav_inner cf">
                <div class="sns">
                    <ul>
                        <li class="blog"><a href="/weblog/" target="_blank"><img src="/new/img/head_blog_sp.png" alt="BLOG">テクノスブログ</a></li>
                        <!--<li><a href="" target="_blank"><img src="/new/img/head_twitter_sp.png" alt="Twitter"></a></li>
                        <li><a href="" target="_blank"><img src="/new/img/head_fb_sp.png" alt="Facebook"></a></li>
                        <li><a href="" target="_blank"><img src="/new/img/head_line_sp.png" alt="LINE@"></a></li>-->
                    </ul>
                </div>

                        <dl class="menulist">
                            <dt class="acc"><a href="/admission/">入学のご案内</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/admission/">募集要項・学費・奨学金</a></li>
                                    <li><a href="/admission/admission.php">入学までの流れ</a></li>
                                    <li><a href="/admission/selection.php">選考方法</a></li>
                                    <li><a href="/admission/ao.php">AO入学</a></li>
                                    <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker01">各種奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
                                    <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <dl class="menulist">
                            <dt class="acc"><a href="/school/">学院案内／教育理念</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/school/greetings.php#unker02">理事長挨拶</a></li>
                                    <li><a href="/school/greetings.php#unker01">建学の精神</a></li>
                                    <li><a href="/school/greetings.php#unker04">沿革</a></li>
                                    <li><a href="/school/greetings.php#unker03">学院長挨拶</a></li>
                                <li><a href="/school/greetings.php/#unker05">情報公開</a></li>
                                </ul>
                            </dd>
                            <dt class="acc"><a href="/campus/">キャンパスライフ</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/campus/facilities.php">施設紹介</a></li>
                                    <li><a href="/campus/club.php">部活・クラブ紹介</a></li>
                                    <li><a href="/campus/internationalweek.php">インターナショナルウィーク</a></li>
                                    <li><a href="/campus/twinneduniv.php">海外姉妹校の紹介</a></li>
                                <li><a href="/campus/sandwich-study-abroad.php">サンドイッチ留学</a></li>
                                    <li><a href="/campus/eng-year-event.php">東京工学院専門学校 年間イベント</a></li>
                                    <li><a href="/campus/air-year-event.php">東京エアトラベル・ホテル専門学校 年間イベント</a></li>
                                </ul>
                            </dd>
                            <dt class="acc">就職への取り組み</dt>
                            <dd>
                                <ul>
                                    <li><a href="/manabi/career.php">キャリア支援プログラム</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <ul class="link_list">
                            <li><a href="/eng/">東京工学院専門学校</a></li>
                            <li><a href="/air/">東京エアトラベル・ホテル専門学校</a></li>
                        <li><a href="/manabi/prag.php">PRAGについて</a></li>
                        <li><a href="/manabi/seminar.php">TECHNOS ゼミについて</a></li>
                            <li><a href="/school/collagecourse.php">大学コース</a></li>
                            <li><a href="/experience/">オープンキャンパス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=5&fsno=1&openExternalBrowser=1" target="_blank">オープンキャンパスのお申し込みはこちら</a></li>
                            <!-- <li><a href="https://technosac.jp/entry/tour.php">学校見学</a></li> -->
                            <li><a href="/experience/">イベント</a></li>
                        <!--
                            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">入学説明会</a></li>
                            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">保護者説明会</a></li>
                            <li><a href="/experience/#daigaku_course">大学コース説明</a></li>
                        -->
                            <li><a href="/access.php">アクセス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1">資料請求</a></li>
                            <li><a href="/forobog.php">卒業生の皆さまへ</a></li>
                            <li><a href="/school/parent.php">保護者の皆さまへ</a></li>
                            <li><a href="/carriercanter/carriercanter.php">企業の皆さまへ</a></li>
                            <li><a href="/inquiry.php">お問い合わせ</a></li>
                            <li><a href="/faq.php">Q&amp;A</a></li>
                            
                        </ul>
                    </div>
        </div>
    </header>
    <!--header/-->

    <div class="stiky onlyPC">
        <ul class="left_list">
            <li class="news">
                <p class="ttl">N E W S</p>
            </li>
        <li><a href="/experience/">オープン<br>キャンパス</a></li>
            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=5&fsno=1&openExternalBrowser=1" target="_blank">オープンキャンパスの<br>お申し込みはこちら</a></li>
            
            <li><a href="/experience/">イ ベ ン ト</a></li>
        </ul>
        <ul class="right_list">
            <!-- <li><a href="https://technosac.jp/entry/tour.php">学 校 見 学</a></li> -->
            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">入学説明会</a></li>
            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">保護者説明会</a></li>
        <li><a href="/school/collagecourse.php">大学コース</a></li>
        </ul>
    
        <div class="news_inner">
            
            <div class="ttl_area">
            <img src="/new/img/news_ttl.png" alt="NEWS">
            <a href="/weblog/news/" class="more">NEWS一覧はこちら</a>
                <p class="close"></p>
            </div>

            <div class="news_cont">
            
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/03/17/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.03.17</p>
                            <p class="newstitle">3/20（土・祝）以降のオープンキャンパスについて</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/02/26/1459.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.02.26</p>
                            <p class="newstitle">【卒業生の皆さまへ】お知らせとお願い</p>
                            <p class="newstxt">
</p>
                        </div>
                    </a>
                </div>
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1659.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【オープンキャンパス参加および学校見学ご希望の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/10/01/1156.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.10.01</p>
                            <p class="newstitle">【2021年4月入学をご検討の皆さまへ】AO入学① エントリー期間延長</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/20/0000.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.20</p>
                            <p class="newstitle">2020 TECHNOS祭　9/20～9/22開催</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.15</p>
                            <p class="newstitle">高等教育の修学支援新制度の対象校となりました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/2056.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">日本学生支援機構奨学金二次募集のお知らせ</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/1400.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">【卒業年次在校生・保護者(保証人)の皆さまへ】在学一年延長選択制度　最終申請</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/08/03/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.08.03</p>
                            <p class="newstitle">夏季休業期間中の窓口業務について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/06/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.06</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】学生支援緊急給付金２次募集について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/01/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.01</p>
                            <p class="newstitle">オープンキャンパスに参加される皆さんへ 新型コロナウイルス感染拡大予防について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
            
            </div>
        </div>
        <!--news_inner-->
    
    </div>

<!--SPニュース-->

<div class="foot_bnr_area">
    <!--<a href="/admission/" class="bnr ao_bnr onlySP"><img src="/new/img/header_bnr_college_sp.png" alt="まだ間に合う！大学コース"></a>-->
    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="bnr">
        <img class="onlyPC" src="/new/img/bnr_education.png" alt="高等教育の就学支援新制度の対象行となりました。">
        <img class="onlySP" src="/new/img/bnr_education_sp.png" alt="高等教育の就学支援新制度の対象行となりました。">
    </a>
</div>

    <div class="oc_btn onlySP cf">
            <p class="news_btn">NEWS</p>
            <a href="/experience/" class="oc">オープンキャンパス</a>

            <div class="news_inner">
                <div class="ttl_area">
                    <img src="/new/img/news_ttl.png" alt="NEWS">
                    <a href="/weblog/news/" class="more">NEWS一覧はこちら</a>
                    <p class="close"></p>
                </div>

                <div class="news_cont">
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/03/17/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.03.17</p>
                            <p class="newstitle">3/20（土・祝）以降のオープンキャンパスについて</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/02/26/1459.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.02.26</p>
                            <p class="newstitle">【卒業生の皆さまへ】お知らせとお願い</p>
                            <p class="newstxt">
</p>
                        </div>
                    </a>
                </div>
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1659.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【オープンキャンパス参加および学校見学ご希望の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/10/01/1156.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.10.01</p>
                            <p class="newstitle">【2021年4月入学をご検討の皆さまへ】AO入学① エントリー期間延長</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/20/0000.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.20</p>
                            <p class="newstitle">2020 TECHNOS祭　9/20～9/22開催</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.15</p>
                            <p class="newstitle">高等教育の修学支援新制度の対象校となりました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/2056.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">日本学生支援機構奨学金二次募集のお知らせ</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/1400.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">【卒業年次在校生・保護者(保証人)の皆さまへ】在学一年延長選択制度　最終申請</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/08/03/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.08.03</p>
                            <p class="newstitle">夏季休業期間中の窓口業務について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/06/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.06</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】学生支援緊急給付金２次募集について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/01/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.01</p>
                            <p class="newstitle">オープンキャンパスに参加される皆さんへ 新型コロナウイルス感染拡大予防について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                
                </div>
            </div>
            <!--news_inner-->
        </div>
        <!--oc_btn-->


    <!---->
   <div class="comingsoonPage">
<img src="/assets/img/current/comingsoon.png" alt="comingsoon">
<p>2022 年度入学の詳細は、後日更新いたします。</p>
</div>

<!--<div class="admission_wrap">
    <div class="h2_box10">
        <h2><img src="/new/img/admission/ao/h2_txt.png" alt="AO入学"></h2>
    </div>
    <div id="ao" class="inner">
        <h3>
            <img src="/new/img/admission/ao/img01.png" alt="TECHNOSのAO入学 AO入学は2タイプ!自分にあった入試方法を選ぼう" class="onlyPC">
            <img src="/new/img/admission/ao/img01_sp.png" alt="TECHNOSのAO入学 AO入学は2タイプ!自分にあった入試方法を選ぼう" class="onlySP">
        </h3>
        <section class="block01 cf">
            <div class="box01 fl">
                <h3>講座受講型（AO入学②）</h3>
                <div class="box_inner01">
                    <p>指定の講座を受講（3回以上、何度でも受講可能）することで、面接・課題提出が免除になり、その成果によって「AO奨学金」の支給を受けられます。</p>
                    <dl>
                        <dt>こんな方にオススメ!</dt>
                        <dd>
                            <ul>
                                <li>やりたいことが<br>決まっている</li>
                                <li>いち早く<br>専門的な学習を<br>スタートしたい</li>
                            </ul>
                        </dd>
                    </dl>
                    <img src="/new/img/admission/ao/box01_img01.png" alt="">
                </div>
                <div class="box_inner02">
                    <p class="ttl">講座受講型</p>
                    <section>
                        <h4>出願までの流れ</h4>
                        <dl class="cf">
                            <dt>STEP <span>1</span></dt>
                            <dd>オープンキャンパス参加</dd>
                        </dl>
                        <dl class="cf">
                            <dt>STEP <span>2</span></dt>
                            <dd>講座受講 <sup>※</sup></dd>
                        </dl>
                        <dl class="cf">
                            <dt>STEP <span>3</span></dt>
                            <dd>エントリー</dd>
                        </dl>
                        <dl class="cf">
                            <dt>STEP <span>4</span></dt>
                            <dd>出願資格認定通知・出願</dd>
                        </dl>
                        <p class="att">※講座受講型で受験する方は学科毎に異なる所定の講座を受講する必要があります。</p>
                    </section>
                    <section>
                        <h4>エントリー期間</h4>
                        <p>2020年6月1日（月）～2021年3月16日（火）</p>
                    </section>
                    <section>
                        <h4>出願受付期間<br><span>（出願資格認定通知に記載された有効期限内）</span></h4>
                        <p>2020年9月1日（火）～2021年3月31日（水）</p>
                    </section>
                </div>
            </div>
            <div class="box02 fr">
                <h3>課題提出・面接型（AO入学①）</h3>
                <div class="box_inner01">
                    <p>入学前に課題（もしくは作文）を提出し、個人面接との総合評価で「AO奨学金」の支給を受けられます。</p>
                    <dl>
                        <dt>こんな方にオススメ!</dt>
                        <dd>
                            <ul>
                                <li>伝えることが得意</li>
                                <li>課題に取り組む<br>のが好き</li>
                            </ul>
                        </dd>
                    </dl>
                    <img src="/new/img/admission/ao/box02_img01.png" alt="">
                </div>
                <div class="box_inner02">
                    <p class="ttl">課題提出・面接型</p>
                    <section>
                        <h4>出願までの流れ</h4>
                        <dl class="cf">
                            <dt>STEP <span>1</span></dt>
                            <dd>オープンキャンパス参加</dd>
                        </dl>
                        <dl class="cf">
                            <dt>STEP <span>2</span></dt>
                            <dd>エントリー</dd>
                        </dl>
                        <dl class="cf">
                            <dt>STEP <span>3</span></dt>
                            <dd>課題提出・面接</dd>
                        </dl>
                        <dl class="cf">
                            <dt>STEP <span>4</span></dt>
                            <dd>出願資格認定通知・出願</dd>
                        </dl>
                    </section>
                    <section>
                        <h4>エントリー期間</h4>
                        <p>１次：2020年6月1日（月）～12月31日（木）<br>２次：2021年1月8日（金）～3月16日（火）</p>
                    </section>
                    <section>
                        <h4>出願受付期間</h4>
                        <p>１次：2020年9月1日（火）～2021年1月31日（日）<br>２次：2021年1月8日（金）～3月31日（水）</p>
                    </section>
                </div>
            </div>
        </section>
        <section class="block02">
            <h3>課題提出・面接型 スケジュール</h3>
            <table>
                <thead>
                    <tr>
                        <th colspan="2">課題提出・面接型</th>
                        <th>エントリー期間</th>
                        <th>面接・課題提出日</th>
                        <th>出願資格認定通知</th>
                        <th>出願受付期間</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td rowspan="10">一次</td>
                        <td>第一回</td>
                        <td>2020年6月1日（月）〜<br>6月3日（水）</td>
                        <td>2020年6月7日（日）</td>
                        <td>2020年6月12日（金）</td>
                        <td rowspan="9">2020年9月1日（火）〜<br>10月20日（火）</td>
                    </tr>
                    <tr>
                        <td>第二回</td>
                        <td>2020年6月4日（木）〜<br>6月16日（火）</td>
                        <td>2020年6月21日（日）</td>
                        <td>2020年6月26日（金）</td>
                    </tr>
                    <tr>
                        <td>第三回</td>
                        <td>2020年6月17日（水）〜<br>6月30日（火）</td>
                        <td>2020年7月5日（日）</td>
                        <td>2020年7月10日（金）</td>
                    </tr>
                    <tr>
                        <td>第四回</td>
                        <td>2020年7月1日（水）〜<br>7月14日（火）</td>
                        <td>2020年7月19日（日）</td>
                        <td>2020年7月25日（土）</td>
                    </tr>
                    <tr>
                        <td>第五回</td>
                        <td>2020年7月15日（水）〜<br>8月4日（火）</td>
                        <td>2020年8月10日（月）</td>
                        <td>2020年8月17日（月）</td>
                    </tr>
                    <tr>
                        <td>第六回</td>
                        <td>2020年8月5日（水）〜<br>8月18日（火）</td>
                        <td>2020年8月23日（日）</td>
                        <td>2020年8月28日（金）</td>
                    </tr>
                    <tr>
                        <td>第七回</td>
                        <td>2020年8月19日（水）〜<br>9月1日（火）</td>
                        <td>2020年9月6日（日）</td>
                        <td>2020年9月11日（金）</td>
                    </tr>
                    <tr>
                        <td>第八回</td>
                        <td>2020年9月2日（水）〜<br>9月15日（火）</td>
                        <td>2020年9月20日（日）</td>
                        <td>2020年9月25日（金）</td>
                    </tr>
                    <tr>
                        <td>第九回</td>
                        <td>2020年9月16日（水）〜<br>9月30日（水）</td>
                        <td>2020年10月4日（日）</td>
                        <td>2020年10月9日（金）</td>
                    </tr>
                    <tr>
                        <td>第十回</td>
                        <td>2020年10月1日（木）〜<br>12月31日（木）</td>
                        <td>随時</td>
                        <td>随時</td>
                        <td>2020年10月21日（水）〜<br>2021年1月31日（日）</td>
                    </tr>
                    <tr>
                        <td colspan="2">二次</td>
                        <td>2021年1月8日（金）〜<br>3月16日（火）</td>
                        <td>随時</td>
                        <td>随時</td>
                        <td>2021年1月8日（金）〜<br>3月31日（水）</td>
                    </tr>
                </tbody>
            </table>
        </section>

        <a class="webEntryBnr" href="/admission/webentry.php"><img src="/new/img/admission/webentry/bnr_webentry.jpg" alt="WEB AOエントリー、WEB出願"></a>

        <section class="block03">
            <h3><img src="/new/img/admission/ao/img02.png" alt="テクノスカレッジのAO入学について、高校生や保護者の方から寄せられる質問にお答えします。" class="onlyPC"><img src="/new/img/admission/ao/img02_sp.png" alt="テクノスカレッジのAO入学について、高校生や保護者の方から寄せられる質問にお答えします。" class="onlySP"></h3>
            <div class="box">
                <dl>
                    <dt><img src="/new/img/admission/ao/q.png" alt="Q"><span>テクノスカレッジのAO入学の特長はどんなところですか?</span></dt>
                    <dd><img src="/new/img/admission/ao/a.png" alt="A">
                        <p>学力だけでなく、人物面や将来の目標などを面接・課題・講座の受講を通して評価する選考方法です。高等学校の推薦書は必要がなく、評定平均値などの制限もありません。みなさんのやる気を評価します。</p>
                    </dd>
                </dl>
            </div>
            <div class="box">
                <dl>
                    <dt><img src="/new/img/admission/ao/q.png" alt="Q"><span>AO入学と推薦・一般入学は何が違うのですか?</span></dt>
                    <dd><img src="/new/img/admission/ao/a.png" alt="A">
                        <p>AO入学選考受験者は入学前から専門分野の学習をすることにより、知識の向上が図られ、推薦・一般入学の学生よりも入学後の学業に取り組みやすくなります。また、課題の評価や面接の結果、受講の成果などにより｢AO奨学金｣を受けることができます。</p>
                    </dd>
                </dl>
            </div>
            <div class="box">
                <dl>
                    <dt><img src="/new/img/admission/ao/q.png" alt="Q"><span>オープンキャンパスは必ず参加しなくてはいけませんか?</span></dt>
                    <dd><img src="/new/img/admission/ao/a.png" alt="A">
                        <p>エントリーには、オープンキャンパス参加が条件の１つとなっております。オープンキャンパスでは、学校の雰囲気や体験授業などを実際に体験できます。また在校生や先生ともお話しでき、受験に関して気軽に相談することもできるので、ぜひ参加してください。</p>
                    </dd>
                </dl>
            </div>
        </section>
        <section class="block04">
            <div class="btm">
                <p>ご不明な点・詳細などは、お気軽にお問い合わせください。</p>
                <div class="cf">
                    <img src="/new/img/admission/ao/img03.png" alt="">
                    <p>東京工学院専門学校</p>
                    <img src="/new/img/admission/ao/img05.png" alt="0120-634-200" class="tel">
                </div>
                <div class="cf">
                    <img src="/new/img/admission/ao/img04.png" alt="">
                    <p>東京エアトラベル・ホテル専門学校</p>
                    <img src="/new/img/admission/ao/img06.png" alt="0120-634-300" class="tel">
                </div>
                <p>E&#45;m&#97;i&#108;：&#105;&#110;f&#111;&#64;&#116;&#101;&#99;hn&#111;&#115;&#46;ac.jp</p>
            </div>
        </section>
    </div>
    <div class="admission_block03 cf">
        <div class="admission_block03_list match">
            <div class="admission_block03_ttl01">
                <h3>入学方法</h3>
            </div>
            <ul>
                <li><a href="/admission/admission.php">入学までの流れ</a></li>
                <li><a href="/admission/selection.php">各種選考方法（推薦・一般・AO）</a></li>
                <li><a href="/admission/ao.php">AO入学とは?</a></li>
            </ul>
        </div>
        <div class="admission_block03_list match">
            <div class="admission_block03_ttl02">
                <h3>学　費</h3>
            </div>
            <ul>
                <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
            </ul>
        </div>
        <div class="admission_block03_list match">
            <div class="admission_block03_ttl03">
                <h3>各種奨学金制度</h3>
            </div>
            <ul>
                <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                <li><a href="/admission/scholarship.php">各種奨学金制度</a></li>
                <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
            </ul>
        </div>
        <div class="admission_block03_list match">
            <div class="admission_block03_ttl04">
                <h3>学校生活</h3>
            </div>
            <ul>
                <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
            </ul>
        </div>
    </div>
</div>
</div>
-->
   <!--/footer-->
    <footer>
    	<div class="inner">
            <p>お電話でのご相談や資料請求・来校のご予約はこちらまで</p>
            <div class="cf">
                <dl>
                    <dt>東京工学院専門学校</dt>
                    <dd><img src="/new/img/kogyo_tel.png" alt="0120-634-200"></dd>
                </dl>
                <dl>
                    <dt>東京エアトラベル・ホテル専門学校</dt>
                    <dd><img src="/new/img/air_tel.png" alt="0120-634-300"></dd>
                </dl>
            </div>

            <div class="add cf">
                <div class="logo">
                <a href="/"><img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a>
                    <p>総合学院テクノスカレッジ</p>
                </div>
                <div class="add_box">
                    <p>府中・小金井インテリジェントキャンパス ： <br class="onlySP">〒184-8543 東京都小金井市前原町5-1-29</p>
                    <p>渋谷サテライトキャンパス ： <br class="onlySP">〒151-0051 東京都渋谷区千駄ケ谷5-30-16</p>
                </div>
                    
                <div class="footerMenu">
                    <a href="/privacypolicy.php">プライバシーポリシー</a>
                </div>
            
            </div>

            <p class="copyright">Copyright © Technos College. All Rights Reserved.</p>
        </div>

        <p id="gotop"><img src="/new/img/gotop.png" alt="gotop"></p>
    </footer>
    <!--footer/-->


</div><!--wrapper/-->

<script type="text/javascript" class="microad_blade_track">
<!--
var microad_blade_jp = microad_blade_jp || { 'params' : new Array(), 'complete_map' : new Object() };
(function() {
var param = {'co_account_id' : '24', 'group_id' : '', 'country_id' : '1', 'ver' : '2.1.0'};

var param_custom =
{
"set_1": {
"item" : "rsnemibl20160805079",
}
}
param.custom = param_custom;

microad_blade_jp.params.push(param);

var src = (location.protocol == 'https:')
? 'https://d-track.send.microad.jp/js/blade_track_jp.js' : 'http://d-cache.microad.jp/js/blade_track_jp.js';

var bs = document.createElement('script');
bs.type = 'text/javascript'; bs.async = true;
bs.charset = 'utf-8'; bs.src = src;

var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(bs, s);
})();
-->
</script>

<!-- add. 0909 recruit -->
<script type="text/javascript" class="microad_blade_track">
<!--
var microad_blade_jp = microad_blade_jp || { 'params' : new Array(), 'complete_map' : new Object() };
(function() {
var param = {'co_account_id' : '24', 'group_id' : '', 'country_id' : '1', 'ver' : '2.1.0'};
microad_blade_jp.params.push(param);

var src = (location.protocol == 'https:')
? 'https://d-track.send.microad.jp/js/blade_track_jp.js' : 'http://d-cache.microad.jp/js/blade_track_jp.js';

var bs = document.createElement('script');
bs.type = 'text/javascript'; bs.async = true;
bs.charset = 'utf-8'; bs.src = src;

var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(bs, s);
})();
-->
</script>


</body>
</html>


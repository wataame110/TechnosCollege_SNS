<!DOCTYPE html>
<html lang="ja">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>各種奨学金制度 | 東京工学院専門学校 / 東京エアトラベル・ホテル専門学校</title>
    <meta name="keywords" content="各種奨学金制度総合学院テクノスカレッジ,東京工学院専門学校,東京エアトラベル・ホテル専門学校" />
    <meta name="description" content="" />
    <meta name="format-detection" content="telephone=no">
    <link rel="canonical" href="" />
    <link rel="shortcut icon" type="image/x-icon" href="/lib/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

<script type="text/javascript" src="//www2.infoclipper.net/infohp_js/751c6lf.js" charset="UTF-8"></script>
<script type="text/javascript" src="//www2.infoclipper.net/infohp_js/fpAnalysis.js" charset="UTF-8"></script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NF9PB6Z');</script>
<!-- End Google Tag Manager -->
    <!--CSS File-->
    <link rel="stylesheet" type="text/css" href="/new/css/reset.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/common.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/new/css/pc_style.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/sp_style.css" media="screen,print">

    <!--TOP CSS-->
<link rel="stylesheet" type="text/css" href="/new/css/admission/pc_style.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/admission/sp_style.css" media="screen,print">

    
    
    <link rel="stylesheet" type="text/css" href="/new/css/slick.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/slick-theme.css" media="screen,print">
    <link rel="stylesheet" type="text/css" href="/new/css/experience/common.css" media="screen,print">
    

    <!--JS File-->
    <script type="text/javascript" src="/new/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="/new/js/jquery.matchHeight.js"></script>
    <script type="text/javascript" src="/new/js/jquery.inview.js"></script>
<script type="text/javascript" src="/new/js/custom.js"></script>
<script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script>

    <!--<script type="text/javascript" src="/new/js/jquery.bxslider.min.js"></script>-->

    
    
    
<script type="text/javascript" src="/lib/js/ga.js"></script>
</head>
<body >
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NF9PB6Z"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="fakeLoader"></div>
<div class="wrapper">
    

    <!--/header-->
    <header>
        <div class="inner cf onlyPC">
            <div class="h1_box">
                <a href="/"><h1>総合学院テクノスカレッジ</h1>
            <img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a>    
            </div>
        
            <nav>
            <!--<a href="/admission/" class="bnr"><img src="/new/img/header_bnr_college.png" alt="まだ間に合う！大学コース"></a>-->
                <div class="sns">
                <a href="/experience/" class="oc_btn_head">オープンキャンパス</a>
                    <ul>
                        <li><a href="https://technosac.jp/weblog/" target="_blank">テクノスブログ</a></li>
                    </ul>
                </div>


                <div class="main_menu">
                    <ul class="mainlist">
                        <li><a href="/eng/">東京工学院専門学校</a></li>
                        <li><a href="/air/">東京エアトラベル・ホテル<br />専門学校</a></li>
                        <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1" target="_blank">資料請求</a></li>
                        <li><a href="/access.php">アクセス</a></li>
                        <li><a class="menu_btn"><span class="menu_btn-icon"></span>MENU</a></li>
                    </ul>

                    <div class="nav_inner cf">
                        <dl class="menulist">
                            <dt><a href="/admission/">入学のご案内</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/admission/">募集要項・学費・奨学金</a></li>
                                    <li><a href="/admission/admission.php">入学までの流れ</a></li>
                                    <li><a href="/admission/selection.php">選考方法</a></li>
                                    <li><a href="/admission/ao.php">AO入学</a></li>
                                    <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker01">各種奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
                                    <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <dl class="menulist">
                            <dt><a href="/school/">学院案内／教育理念</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/school/greetings.php#unker02">理事長挨拶</a></li>
                                    <li><a href="/school/greetings.php#unker01">建学の精神</a></li>
                                    <li><a href="/school/greetings.php#unker04">沿革</a></li>
                                    <li><a href="/school/greetings.php#unker03">学院長挨拶</a></li>
                                <li><a href="/school/greetings.php/#unker05">情報公開</a></li>
                                </ul>
                            </dd>
                            <dt><a href="/campus/">キャンパスライフ</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/campus/facilities.php">施設紹介</a></li>
                                    <li><a href="/campus/club.php">部活・クラブ紹介</a></li>
                                    <li><a href="/campus/internationalweek.php">インターナショナルウィーク</a></li>
                                    <li><a href="/campus/twinneduniv.php">海外姉妹校の紹介</a></li>
                                <li><a href="/campus/sandwich-study-abroad.php">サンドイッチ留学</a></li>
                                    <li><a href="/campus/eng-year-event.php">東京工学院専門学校 年間イベント</a></li>
                                    <li><a href="/campus/air-year-event.php">東京エアトラベル・ホテル専門学校 年間イベント</a></li>
                                </ul>
                            </dd>
                            <dt>就職への取り組み</dt>
                            <dd>
                                <ul>
                                    <li><a href="/manabi/career.php">キャリア支援プログラム</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <ul class="link_list">
                            <li><a href="/eng/">東京工学院専門学校</a></li>
                            <li><a href="/air/">東京エアトラベル・ホテル専門学校</a></li>
                        <li><a href="/manabi/prag.php">PRAGについて</a></li>
                        <li><a href="/manabi/seminar.php">TECHNOS ゼミについて</a></li>
                            <li><a href="/school/collagecourse.php">大学コース</a></li>
                            <li><a href="/experience/">オープンキャンパス</a></li>
                            <li><a href="/access.php">アクセス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1">資料請求</a></li>
                            <li><a href="/forobog.php">卒業生の皆さまへ</a></li>
                            <li><a href="/school/parent.php">保護者の皆さまへ</a></li>
                            <li><a href="/carriercanter/carriercanter.php">企業の皆さまへ</a></li>
                            <li><a href="/inquiry.php">お問い合わせ</a></li>
                            <li><a href="/faq.php">Q&amp;A</a></li>
                        <li class="middle"><a href="https://technosac.jp/weblog/" target="_blank">テクノスブログ</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

        <div class="onlySP">
            <ul class="main_nav cf">
                <li><a href="/"><img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a></li>
                <li><a href="/eng/"><img src="/new/img/sp_menu01.png" alt="東京工学院専門学校"></a></li>
                <li><a href="/air/"><img src="/new/img/sp_menu02.png" alt="東京エアトラベル・ホテル専門学校"></a></li>
                <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1"><img src="/new/img/sp_menu03.png" alt="資料請求"></a></li>
                <li><a href="/access.php"><img src="/new/img/sp_menu04.png" alt="アクセス"></a></li>
                <li><a class="menu_btn"><span class="menu_btn-icon"></span><p>MENU</p></a></li>
            </ul>

            <div class="nav_inner cf">
                <div class="sns">
                    <ul>
                        <li class="blog"><a href="/weblog/" target="_blank"><img src="/new/img/head_blog_sp.png" alt="BLOG">テクノスブログ</a></li>
                        <!--<li><a href="" target="_blank"><img src="/new/img/head_twitter_sp.png" alt="Twitter"></a></li>
                        <li><a href="" target="_blank"><img src="/new/img/head_fb_sp.png" alt="Facebook"></a></li>
                        <li><a href="" target="_blank"><img src="/new/img/head_line_sp.png" alt="LINE@"></a></li>-->
                    </ul>
                </div>

                        <dl class="menulist">
                            <dt class="acc"><a href="/admission/">入学のご案内</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/admission/">募集要項・学費・奨学金</a></li>
                                    <li><a href="/admission/admission.php">入学までの流れ</a></li>
                                    <li><a href="/admission/selection.php">選考方法</a></li>
                                    <li><a href="/admission/ao.php">AO入学</a></li>
                                    <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
                                    <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker01">各種奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                                    <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
                                    <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <dl class="menulist">
                            <dt class="acc"><a href="/school/">学院案内／教育理念</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/school/greetings.php#unker02">理事長挨拶</a></li>
                                    <li><a href="/school/greetings.php#unker01">建学の精神</a></li>
                                    <li><a href="/school/greetings.php#unker04">沿革</a></li>
                                    <li><a href="/school/greetings.php#unker03">学院長挨拶</a></li>
                                <li><a href="/school/greetings.php/#unker05">情報公開</a></li>
                                </ul>
                            </dd>
                            <dt class="acc"><a href="/campus/">キャンパスライフ</a></dt>
                            <dd>
                                <ul>
                                    <li><a href="/campus/facilities.php">施設紹介</a></li>
                                    <li><a href="/campus/club.php">部活・クラブ紹介</a></li>
                                    <li><a href="/campus/internationalweek.php">インターナショナルウィーク</a></li>
                                    <li><a href="/campus/twinneduniv.php">海外姉妹校の紹介</a></li>
                                <li><a href="/campus/sandwich-study-abroad.php">サンドイッチ留学</a></li>
                                    <li><a href="/campus/eng-year-event.php">東京工学院専門学校 年間イベント</a></li>
                                    <li><a href="/campus/air-year-event.php">東京エアトラベル・ホテル専門学校 年間イベント</a></li>
                                </ul>
                            </dd>
                            <dt class="acc">就職への取り組み</dt>
                            <dd>
                                <ul>
                                    <li><a href="/manabi/career.php">キャリア支援プログラム</a></li>
                                </ul>
                            </dd>
                        </dl>
                        <ul class="link_list">
                            <li><a href="/eng/">東京工学院専門学校</a></li>
                            <li><a href="/air/">東京エアトラベル・ホテル専門学校</a></li>
                        <li><a href="/manabi/prag.php">PRAGについて</a></li>
                        <li><a href="/manabi/seminar.php">TECHNOS ゼミについて</a></li>
                            <li><a href="/school/collagecourse.php">大学コース</a></li>
                            <li><a href="/experience/">オープンキャンパス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=5&fsno=1&openExternalBrowser=1" target="_blank">オープンキャンパスのお申し込みはこちら</a></li>
                            <!-- <li><a href="https://technosac.jp/entry/tour.php">学校見学</a></li> -->
                            <li><a href="/experience/">イベント</a></li>
                        <!--
                            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">入学説明会</a></li>
                            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">保護者説明会</a></li>
                            <li><a href="/experience/#daigaku_course">大学コース説明</a></li>
                        -->
                            <li><a href="/access.php">アクセス</a></li>
                            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=1&fsno=1&openExternalBrowser=1">資料請求</a></li>
                            <li><a href="/forobog.php">卒業生の皆さまへ</a></li>
                            <li><a href="/school/parent.php">保護者の皆さまへ</a></li>
                            <li><a href="/carriercanter/carriercanter.php">企業の皆さまへ</a></li>
                            <li><a href="/inquiry.php">お問い合わせ</a></li>
                            <li><a href="/faq.php">Q&amp;A</a></li>
                            
                        </ul>
                    </div>
        </div>
    </header>
    <!--header/-->

    <div class="stiky onlyPC">
        <ul class="left_list">
            <li class="news">
                <p class="ttl">N E W S</p>
            </li>
        <li><a href="/experience/">オープン<br>キャンパス</a></li>
            <li><a href="https://www.school-go.info/19gi13/technosac/form.php?fno=5&fsno=1&openExternalBrowser=1" target="_blank">オープンキャンパスの<br>お申し込みはこちら</a></li>
            
            <li><a href="/experience/">イ ベ ン ト</a></li>
        </ul>
        <ul class="right_list">
            <!-- <li><a href="https://technosac.jp/entry/tour.php">学 校 見 学</a></li> -->
            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">入学説明会</a></li>
            <li><a href="/experience/program/#otherProgram" data-tor-smoothscroll="noSmooth">保護者説明会</a></li>
        <li><a href="/school/collagecourse.php">大学コース</a></li>
        </ul>
    
        <div class="news_inner">
            
            <div class="ttl_area">
            <img src="/new/img/news_ttl.png" alt="NEWS">
            <a href="/weblog/news/" class="more">NEWS一覧はこちら</a>
                <p class="close"></p>
            </div>

            <div class="news_cont">
            
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/03/17/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.03.17</p>
                            <p class="newstitle">3/20（土・祝）以降のオープンキャンパスについて</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/02/26/1459.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.02.26</p>
                            <p class="newstitle">【卒業生の皆さまへ】お知らせとお願い</p>
                            <p class="newstxt">
</p>
                        </div>
                    </a>
                </div>
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1659.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【オープンキャンパス参加および学校見学ご希望の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/10/01/1156.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.10.01</p>
                            <p class="newstitle">【2021年4月入学をご検討の皆さまへ】AO入学① エントリー期間延長</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/20/0000.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.20</p>
                            <p class="newstitle">2020 TECHNOS祭　9/20～9/22開催</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.15</p>
                            <p class="newstitle">高等教育の修学支援新制度の対象校となりました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/2056.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">日本学生支援機構奨学金二次募集のお知らせ</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/1400.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">【卒業年次在校生・保護者(保証人)の皆さまへ】在学一年延長選択制度　最終申請</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/08/03/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.08.03</p>
                            <p class="newstitle">夏季休業期間中の窓口業務について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/06/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.06</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】学生支援緊急給付金２次募集について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/01/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.01</p>
                            <p class="newstitle">オープンキャンパスに参加される皆さんへ 新型コロナウイルス感染拡大予防について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
            
            </div>
        </div>
        <!--news_inner-->
    
    </div>

<!--SPニュース-->

<div class="foot_bnr_area">
    <!--<a href="/admission/" class="bnr ao_bnr onlySP"><img src="/new/img/header_bnr_college_sp.png" alt="まだ間に合う！大学コース"></a>-->
    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="bnr">
        <img class="onlyPC" src="/new/img/bnr_education.png" alt="高等教育の就学支援新制度の対象行となりました。">
        <img class="onlySP" src="/new/img/bnr_education_sp.png" alt="高等教育の就学支援新制度の対象行となりました。">
    </a>
</div>

    <div class="oc_btn onlySP cf">
            <p class="news_btn">NEWS</p>
            <a href="/experience/" class="oc">オープンキャンパス</a>

            <div class="news_inner">
                <div class="ttl_area">
                    <img src="/new/img/news_ttl.png" alt="NEWS">
                    <a href="/weblog/news/" class="more">NEWS一覧はこちら</a>
                    <p class="close"></p>
                </div>

                <div class="news_cont">
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/03/17/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.03.17</p>
                            <p class="newstitle">3/20（土・祝）以降のオープンキャンパスについて</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/02/26/1459.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.02.26</p>
                            <p class="newstitle">【卒業生の皆さまへ】お知らせとお願い</p>
                            <p class="newstxt">
</p>
                        </div>
                    </a>
                </div>
                
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2021/01/07/1659.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2021.01.07</p>
                            <p class="newstitle">【オープンキャンパス参加および学校見学ご希望の皆さまへ】</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/10/01/1156.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.10.01</p>
                            <p class="newstitle">【2021年4月入学をご検討の皆さまへ】AO入学① エントリー期間延長</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/20/0000.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.20</p>
                            <p class="newstitle">2020 TECHNOS祭　9/20～9/22開催</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/15/1700.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.15</p>
                            <p class="newstitle">高等教育の修学支援新制度の対象校となりました</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/2056.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">日本学生支援機構奨学金二次募集のお知らせ</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/09/04/1400.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.09.04</p>
                            <p class="newstitle">【卒業年次在校生・保護者(保証人)の皆さまへ】在学一年延長選択制度　最終申請</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/08/03/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.08.03</p>
                            <p class="newstitle">夏季休業期間中の窓口業務について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/06/1600.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.06</p>
                            <p class="newstitle">【在校生・保護者(保証人)の皆さまへ】学生支援緊急給付金２次募集について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                <div class="box">
                    <a href="https://technosac.jp/weblog/2020/07/01/1317.php" class="cf">
                        <div class="img_box">
                            
                                <img src="/new/img/noimage.png" alt="">
                            
                        </div>
                        <div class="txt_box">
                            <p class="date">2020.07.01</p>
                            <p class="newstitle">オープンキャンパスに参加される皆さんへ 新型コロナウイルス感染拡大予防について</p>
                            <p class="newstxt"></p>
                        </div>
                    </a>
                </div>
                
                
                </div>
            </div>
            <!--news_inner-->
        </div>
        <!--oc_btn-->


    <!---->
   <div class="comingsoonPage">
<img src="/assets/img/current/comingsoon.png" alt="comingsoon">
<p>2022 年度入学の詳細は、後日更新いたします。</p>
</div>

<!--<div class="admission_wrap">
    <div class="h2_box9">
        <h2><img src="/new/img/admission/scholarship/pc_h2_txt.png" alt="各種奨学金／本校独自の奨学金／公的な奨学金制度と教育ローン" class="onlyPC"><img src="/new/img/admission/scholarship/sp_h2_txt.png" alt="各種奨学金／本校独自の奨学金／公的な奨学金制度と教育ローン" class="onlySP"></h2>
    </div>
    <div id="admission">
        <div class="ship_navi cf">
            <ul>
                <li><a href="#unker01" data-tor-smoothscroll="noSmooth">各種奨学金</a></li>
                <li><a href="#unker02" data-tor-smoothscroll="noSmooth">本校独自の奨学金</a></li>
                <li><a href="#unker03" data-tor-smoothscroll="noSmooth">公的な奨学金制度と<br class="onlyPC">教育ローン</a></li>
            </ul>
        </div>
        <p class="ship_txt01">総合学院テクノスカレッジでは、あなたのガンバリをサポートするために、<br class="onlyPC">さまざまな奨学金制度をご用意しています。ぜひ活用してください!</p>

        <div class="ship_ttl01 pagetopMargin" name="unker01" id="unker01">
            <h2><img src="/new/img/admission/scholarship/h2_txt_02.png" alt="各種奨学金"></h2>
        </div>
        <div class="inner admission_B">
          
            <h3>スポーツ特待生奨学金制度</h3>
            <div class="cont_bs02 cf">
                <div class="ship_left01">
                    <div class="ship_block01 cf">
                        <h4>制度概要</h4>
                        <div>
                            <p>スポーツ特待生奨学金制度とは、高等学校在学中に運動部に所属し積極的に活動した方で本校入学に際して明確な目標を持ち、運動部で活動中に培った積極性やスポーツマン精神を本校においても発揮できる方に支給される奨学金です。</p>
                            <p>運動部での活動内容や各種試合、大会での成績、また本校入学後の部活動参加の有無などを考慮して<span class="onlyPC">右</span><span class="onlySP">下</span>記のランクにより免除いたします。（尚、奨学金は入学年度の納入金より免除されます。）</p>
                            <p>より詳細な情報は、資料請求のお申し込みにより送付されるパンフレット付属の「募集要項」を参照してください。</p>
                        </div>
                    </div>
                </div>
                <div class="ship_right01">
                    <table>
                        <tbody>
                            <tr>
                                <th>ランク</th>
                                <th>奨学金金額（免除額）</th>
                            </tr>
                            <tr>
                                <td>SS</td>
                                <td>1年次の学費全額</td>
                            </tr>
                            <tr>
                                <td>SA</td>
                                <td>1年次の授業料全額</td>
                            </tr>
                            <tr>
                                <td>SB</td>
                                <td>1年次の授業料半額</td>
                            </tr>
                            <tr>
                                <td>S</td>
                                <td>200,000円</td>
                            </tr>
                            <tr>
                                <td>A</td>
                                <td>100,000円</td>
                            </tr>
                            <tr>
                                <td>B</td>
                                <td>50,000円</td>
                            </tr>
                            <tr>
                                <td>C</td>
                                <td>30,000円</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <h3>文化クラブ・課外活動特待生奨学金制度</h3>
            <div class="cont_bs02 cf">
                <div class="ship_left01">
                    <div class="ship_block01 cf">
                        <h4>制度概要</h4>
                        <div>
                            <p>文化クラブ・課外活動特待生奨学金制度とは、高等学校在学中に文化クラブ、または生徒会やボランティアなどの課外活動に所属し積極的に活動した方で本校入学に際して明確な目標を持ち、文化クラブや課外活動で培った積極性や知識、経験を本校においても発揮できる方に支給される奨学金です。</p>
                            <p>文化クラブ、課外活動での活動内容や各種大会などでの成績を考慮して<span class="onlyPC">右</span><span class="onlySP">下</span>記のランクにより免除いたします。（尚、奨学金は入学年度の納入金より免除されます。）</p>
                            <p>より詳細な情報は、資料請求のお申し込みにより送付されるパンフレット付属の「募集要項」を参照してください。</p>
                        </div>
                    </div>
                </div>
                <div class="ship_right01">
                    <table>
                        <tbody>
                            <tr>
                                <th>ランク</th>
                                <th>奨学金金額（免除額）</th>
                            </tr>
                            <tr>
                                <td>SS</td>
                                <td>1年次の学費全額</td>
                            </tr>
                            <tr>
                                <td>SA</td>
                                <td>1年次の授業料全額</td>
                            </tr>
                            <tr>
                                <td>SB</td>
                                <td>1年次の授業料半額</td>
                            </tr>
                            <tr>
                                <td>S</td>
                                <td>200,000円</td>
                            </tr>
                            <tr>
                                <td>A</td>
                                <td>100,000円</td>
                            </tr>
                            <tr>
                                <td>B</td>
                                <td>50,000円</td>
                            </tr>
                            <tr>
                                <td>C</td>
                                <td>30,000円</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <h3>学歴・仕事経験優遇制度</h3>
            <div class="cont_bs02 cf">
                <div class="ship_block02 cf">
                    <h4>制度概要</h4>
                    <div class="ship_pt01">
                        <p>学歴・仕事経験優遇制度は、過去に大学・短大・専門学校での勉学や社会での仕事を経験され、その経験をさらに本校で高めようとする方を支援する制度で、一定の条件を満たすと入学金の一部または半額が免除されます。</p>
                    </div>
                </div>
                <div class="ship_block03">
                    <table>
                        <tbody>
                            <tr>
                                <th>ランク</th>
                                <th>大学・短大・専門学校・社会経験の内容</th>
                                <th>免除額</th>
                            </tr>
                            <tr>
                                <td>A</td>
                                <td>4年制大学または、4年制専門学校を卒業した方、もしくは卒業見込みの方<br>高等学校卒業後、1年以上同一の会社での仕事経験がある方</td>
                                <td>100,000円</td>
                            </tr>
                            <tr>
                                <td>B</td>
                                <td>短期大学または2年制専門学校を卒業した方、もしくは卒業見込みの方<br>
                                    大学・短期大学において62単位以上を取得した方<br>
                                    高等専門学校5年制課程を卒業した方、もしくは卒業見込みの方</td>
                                <td>50,000円</td>
                            </tr>
                            <tr>
                                <td>C</td>
                                <td>大学・短期大学において31単位以上を取得した方<br>
                                    高等学校卒業後、合計で6ヶ月以上の仕事経験がある方<br>
                                    専門学校に1年以上在籍した方</td>
                                <td>30,000円</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="ship_block03">
                    <h4>他奨学金との併用について</h4>
                    <p>特待生奨学金、AO奨学金、資格奨学金、スポーツ特待生奨学金、文化クラブ・課外活動特待生奨学金と学歴・仕事経験優遇制度のいずれか金額の高い方を優先します。（二重に受ける事はできません。）自宅外通学者補助制度を利用される方は併せて受ける事ができます。</p>
                    <h4>大学、短期大学、専門学校での勉学経験を利用される方</h4>
                    <p>大学、短期大学、専門学校での勉学経験を利用される方は、それぞれの学校からの証明書を提出していただきます。又、仕事経験を利用される方は本校指定の用紙にその内容を記入して提出していただきます。仕事経験とは、正社員、アルバイトの種別を問いません。<br>※海外の大学・短大を卒業もしくは見込みの方も対象です。</p>
                </div>
            </div>
            <h3>自宅外通学者補助制度</h3>
            <div class="cont_bs02 cf">
                <div class="ship_block02 cf">
                    <h4>制度概要</h4>
                    <div>
                        <p>自宅外通学者補助制度とは、親元から離れて自宅以外の場所（アパート・学生会館）から通学する学生に対し学費の一部を補助する制度です。距離的に自宅からの通学が不可能な学生に対し常識の範囲内で適用します。（ただし、一人暮らしの方に限ります。また学費全額免除の奨学金を受ける方は該当しません。）<br><small>※入学時（4月）にアパート・学生会館などの契約書コピーを提出していただきます。</small></p>
                        <p><em class="ship_txt02">1年次100,000円を支給します。<br>1年次、学費完納の確認後に前期末（9月）、後期末（3月）にそれぞれ50,000円を支給します。</em><br>
                            （ただし本校学生寮「Felice前原町」入寮者は該当しません。）<br><small>※指定の口座に振り込み</small></p>
                    </div>
                </div>
            </div>
            <h3>AO奨学金制度・学費免除額一覧</h3>
            <div class="cont_bs02 cf">
                <div class="ship_left01 cf">
                    <div class="ship_block01 cf">
                        <h4>制度概要</h4>
                        <div>
                            <p>AO奨学金とは、AO入学の面接及び課題の内容、受講の成果を評価して、本校入学後にも勉学意欲を継続していただく為に与える奨学金です。</p>
                            <p>AO入学の評価ランクS〜Cの金額を入学年度の納入金から免除します。</p>
                            <p>より詳細な情報は、資料請求のお申し込みにより送付されるパンフレット付属の「募集要項」を参照してください。</p>
                        </div>
                    </div>
                </div>
                <div class="ship_right01 cf">
                    <table>
                        <tbody>
                            <tr>
                                <th>ランク</th>
                                <th>奨学金金額（免除額）</th>
                            </tr>
                            <tr>
                                <td>S</td>
                                <td>200,000円</td>
                            </tr>
                            <tr>
                                <td>A</td>
                                <td>100,000円</td>
                            </tr>
                            <tr>
                                <td>B</td>
                                <td>50,000円</td>
                            </tr>
                            <tr>
                                <td>C</td>
                                <td>30,000円</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="ship_block01 audition">
                    <p>※学科によってはSA（1年次の授業料全額）、SB（1年次の授業料半額）ランクの奨学金が与えられるオーディション形式の選考も実施しております。詳細は<a href="/admission/audition/introduction.php" target="_blank">Technosオーディション</a>をご覧ください。（なお、奨学金は入学年度の納入金から免除されます。）</p>
                </div>


            </div>
            <h3>資格奨学金制度</h3>
            <div class="cont_bs02 cf">
                <div class="ship_block02 cf">
                    <h4>制度概要</h4>
                    <div>
                        <p>資格奨学金制度とは、すでに取得している資格の内容により与える奨学金です。評価ランクS〜Cの金額を入学年度の納入金から免除します。（出願時に合格証などのコピーを添えてください。）</p>
                        <p>特待生奨学金、AO奨学金、学歴・仕事経験優遇制度、スポーツ特待生奨学金、文化クラブ・課外活動特待生奨学金と資格奨学金のいずれか金額の高い方を優先します。（二重に受ける事はできません。）</p>
                        <p>自宅外通学者補助制度を利用される方は併せて受ける事ができます。</p>
                    </div>
                </div>
                <div class="ship_txt03"><span>東京工学院専門学校</span></div>
                <div class="ship_block04">
                    <table>
                        <tbody>
                            <tr>
                                <th>ランク</th>
                                <th>金　額</th>
                                <th>資　格</th>
                            </tr>
                            <tr>
                                <td>S</td>
                                <td>200,000円</td>
                                <td>●基本情報技術者以上（経済産業省）<br>
                                    ●第三種電気主任技術者以上（経済産業省）<br>
                                    ●TOEIC 500点以上<br>
                                    ●医療秘書技能検定1級<br>
                                    ●宅地建物取引士<br>
                                    ●ピアノ・電子オルガングレード（ヤマハ：5級以上/カワイ：6級以上）<br>
                                    ●実用英語技能検定2級（日本英語検定協会）</td>
                            </tr>
                            <tr>
                                <td>A</td>
                                <td>100,000円</td>
                                <td>
                                    ●第一種電気工事士（経済産業省）<br>
                                    ●ITパスポート試験（経済産業省）<br>
                                    ●日商PC検定試験2級以上（日本商工会議所）<br>
                                    ●基礎指導員（日本水泳連盟）<br>
                                    ●保育技術検定1級（全国高等学校家庭科教育振興会）<br>
                                    ●簿記検定2級以上（日本商工会議所）<br>
                                    ●医療秘書技能検定準1級<br>
                                    ●救急法救急員（日本赤十字社）<br>
                                    ●ピアノ・電子オルガングレード（ヤマハ：7級/カワイ8級）<br>
                                    ●本校指定（主催）コンテスト優勝者</td>
                            </tr>
                            <tr>
                                <td>B</td>
                                <td>50,000円</td>
                                <td>●情報技術検定1級（全国工業高等学校長協会）<br>
                                    ●情報処理検定1級（全国商業高等学校協会）<br>
                                    ●マイクロソフトオフィススペシャリスト（エキスパートレベル）相当<br>
                                    ●簿記能力検定2級以上（全国経理教育協会）<br>
                                    ●簿記検定3級（日本商工会議所）<br>
                                    ●情報検定1級（文部科学省）<br>
                                    ●医療秘書技能検定2級<br>
                                    ●秘書技能検定2級以上（実務技能検定協会）<br>
                                    ●日商PC検定試験3級（日本商工会議所）<br>
                                    ●ジュニアマイスターゴールド<br>
                                    ●工事担任者AI・DD総合種（総務省）<br>
                                    ●建築CAD検定3級（全国建築CAD連盟）<br>
                                    ●日本漢字能力検定2級以上（日本漢字能力検定協会）<br>
                                    ●第二種電気工事士（経済産業省）<br>
                                    ●ピアノ・電子オルガングレード（ヤマハ：10級以上/カワイ：11級以上）<br>
                                    ●レクリエーション指導員（日本レクリエーション協会）<br>
                                    ●サッカー公認審判員3級（日本サッカー協会）<br>
                                    ●チャレンジプログラム修了者<br>
                                    ●皆勤（高校入学後、出願時まで）<br>
                                    ●色彩検定2級<br>
                                    ●2級施工管理技術検定（学科合格）<br>
                                    ●ビジネス実務法務検定3級（東京商工会議所）<br>
                                    ●福祉住環境コーディネーター2級（東京都商工会議所）<br>
●保育技術検定2級（全国高等学校家庭科教育振興会）</td>
                            </tr>
                            <tr>
                                <td>C</td>
                                <td>30,000円</td>
                                <td>●簿記実務検定3級（全国商業高等学校協会）<br>
                                    ●簿記能力検定3級（全国経理教育協会）<br>
                                    ●情報技術検定2級（全国工業高等学校長協会）<br>
                                    ●情報処理検定2級（全国商業高等学校協会）<br>
                                    ●日本漢字能力検定3級以上（日本漢字能力検定協会）<br>
                                    ●ジュニアマイスターシルバー取得者<br>
                                    ●マイクロソフトオフィススペシャリスト（スペシャリスト）相当<br>
●保育技術検定3級（全国高等学校家庭科教育振興会）<br>
                                    ●工事担任者AI第3種、DD第3種（総務省）<br>
                                    ●情報検定3級以上（文部科学省）<br>
                                    ●数学検定2級以上（日本数学検定協会）<br>
                                    ●ディジタル技術検定3級以上<br>
                                    ●サッカー公認審判員4級（日本サッカー協会）<br>
                                    ●レタリング技能検定3級以上（文部科学省）<br>
                                    ●精勤（高校入学後、出願時まで)<br>
                                    ●色彩検定3級<br>
                                    ●上記以外の資格、検定合格（公共機関、団体等の主催)で過去3年間に取得したもの</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <p>※出願時に証明できるものを提出のこと（コピー添付）<br>※本校主催の研修プログラムを修了した場合、その内容に応じて上記ランクのいずれかの奨学金を支給します。</p>
                <div class="ship_txt04"><span>東京エアトラベル・ホテル専門学校</span></div>
                <div class="ship_block05">
                    <table>
                        <tbody>
                            <tr>
                                <th>ランク</th>
                                <th>金　額</th>
                                <th>資　格</th>
                            </tr>
                            <tr>
                                <td>S</td>
                                <td>200,000円</td>
                                <td>●TOEFL 460点以上（Computer Score140点以上)<br>
                                    ●TOEIC（公開テスト）500点以上<br>
                                    ●実用英語技能検定2級（日本英語検定協会）<br>
                                    ●総合旅行業務取扱管理者（国土交通省）</td>
                            </tr>
                            <tr>
                                <td>A</td>
                                <td>100,000円</td>
                                <td>●TOEIC（公開テスト）400点以上<br>
                                    ●国内旅行業務取扱管理者（国土交通省）<br>
                                    ●本校指定（主催）コンテスト優勝者<br>
                                    ●日商PC検定試験2級以上（日本商工会議所）<br>
                                    ●簿記検定2級以上（日本商工会議所）<br>
                                    ●救急法救急員（日本赤十字社）<br>
                                    ●実用英語技能検定準2級（日本英語検定協会）</td>
                            </tr>
                            <tr>
                                <td>B</td>
                                <td>50,000円</td>
                                <td>●簿記能力検定2級以上（全国経理教育協会）<br>
                                    ●簿記実務検定2級以上（全国商業高等学校協会）<br>
                                    ●簿記検定3級（日本商工会議所）<br>
                                    ●秘書技能検定2級以上（実務技能検定協会）<br>
                                    ●日商PC検定試験3級（日本商工会議所）<br>
                                    ●日本漢字能力検定2級以上（日本漢字能力検定協会）<br>
                                    ●チャレンジプログラム修了者<br>
                                    
                                    ●皆勤（高校入学後、出願時まで）</td>
                            </tr>
                            <tr>
                                <td>C</td>
                                <td>30,000円</td>
                                <td>●簿記実務検定3級（全国商業高等学校協会）<br>
                                    ●簿記能力検定3級（全国経理教育協会）<br>
                                    ●日本漢字能力検定3級以上（日本漢字能力検定協会）<br>
                                    
                                    ●精勤（高校入学後、出願時まで）<br>
                                    ●クラブ活動を3年間続けた方<br>
                                    ●ボランティア活動に従事した方<br>
                                    ●ジュニアマイスター取得者<br>
                                    ●上記以外の資格、検定合格（公共機関、団体等の主催）で過去3年間に取得したもの</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <p>※出願時に証明できるものを提出のこと（コピー添付）</p>
            </div>

            <a class="webEntryBnr" href="/admission/webentry.php"><img src="/new/img/admission/webentry/bnr_webentry.jpg" alt="WEB AOエントリー、WEB出願"></a>

        </div>
        <div class="ship_ttl03 pagetopMargin" name="unker02" id="unker02">
            <h2><img src="/new/img/admission/scholarship/h2_txt_03.png" alt="本校独自の奨学金"></h2>
        </div>
        <div class="inner admission_B">
            <h3>田中育英会奨学金制度<br class="onlySP">（無利子貸与の奨学金）</h3>
            <div class="cont_bs02 cf">
                <p>本校の新入生で目的意識が明確で、かつ経済的理由により学費の援助を要する方に、無利子で貸与する制度です。</p>
                <div class="ship_block06">
                    <table class="sp_bdnone">
                        <tbody>
                            <tr>
                                <th>対　　象</th>
                                <td>校友会・同窓会奨学生、大学・短大併願者を除く希望者</td>
                            </tr>
                            <tr>
                                <th>金　　額</th>
                                <td>500,000円以内</td>
                            </tr>
                            <tr>
                                <th>申込方法</th>
                                <td>出願時に願書の該当欄に◯印を付ける</td>
                            </tr>
                            <tr>
                                <th>選考方法</th>
                                <td>入学選考の合格者に対し奨学金申込書類を別途送付する。その内容を審査し貸与の可否と金額を決定する。</td>
                            </tr>
                            <tr>
                                <th>申込締切日</th>
                                <td>2021年1月31日（日）</td>
                            </tr>
                            <tr>
                                <th>返済方法</th>
                                <td>本校卒業後、6ヶ月を経た後、5年以内に分割又は一括にて返済</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <h3>校友会・同窓会奨学金制度<br class="onlySP">（無利子貸与の奨学金）</h3>
            <div class="cont_bs02 cf">
                <p>本校の新入生で勉学意欲があり、将来積極的に校友会・同窓会活動に参加する意志があり、かつ経済的理由により学費の援助を要する方に、無利子で貸与する制度です。</p>
                <div class="ship_block06">
                    <table class="sp_bdnone">
                        <tbody>
                            <tr>
                                <th>対　　象</th>
                                <td>田中育英会奨学生、大学・短大併願者を除く希望者</td>
                            </tr>
                            <tr>
                                <th>金　　額</th>
                                <td>500,000円以内</td>
                            </tr>
                            <tr>
                                <th>申込方法</th>
                                <td>出願時に願書の該当欄に◯印を付ける</td>
                            </tr>
                            <tr>
                                <th>選考方法</th>
                                <td>入学選考の合格者に対し奨学金申込書類を別途送付する。その内容を審査し貸与の可否と金額を決定する。</td>
                            </tr>
                            <tr>
                                <th>申込締切日</th>
                                <td>2021年1月31日（日）</td>
                            </tr>
                            <tr>
                                <th>返済方法</th>
                                <td>本校卒業後、6ヶ月を経た後、5年以内に分割又は一括にて返済</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <h3>校友会・同窓会・及び在校生紹介優遇制度</h3>
            <div class="cont_bs02 cf">
                <p>本校を卒業された会員、及び本校在校生の兄弟、姉妹、お子様、知人に対する優遇制度です。</p>
                <div class="ship_block06 bk6">
                    <table class="sp_bdnone">
                        <tbody>
                            <tr>
                                <th>会員及び本校在校生の兄弟・姉妹が入学の場合</th>
                                <td>授業料100,000円免除</td>
                            </tr>
                            <tr>
                                <th>会員及び卒業生のご子息・ご子女が入学の場合</th>
                                <td>授業料200,000円免除</td>
                            </tr>
                            <tr>
                                <th>会員及び本校在校生の知人紹介の場合</th>
                                <td>選考料20,000円免除</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="unker02_lastb">
                <div class="cf">
                    <div class="lastb_left">
                        <div>お申し込み・お問い合わせは</div>
                        <p>総合学院テクノスカレッジ<br>東京工学院専門学校 事務局 入学課<br>東京エアトラベル・ホテル専門学校 事務局 入学課</p>
                    </div>
                    <div class="lastb_right">
                        <div><img src="/new/img/admission/scholarship/tel_img_01.png" alt="TEL:042-387-5111"></div>
                        <p><small>紹介状や願書等に必要な書類を郵送させて頂きます。</small></p>
                    </div>
                </div>
            </div>

            <a class="webEntryBnr" href="/admission/webentry.php"><img src="/new/img/admission/webentry/bnr_webentry.jpg" alt="WEB AOエントリー、WEB出願"></a>

        </div>
        <div class="ship_ttl04 pagetopMargin" name="unker03" id="unker03">
            <h2><img src="/new/img/admission/scholarship/pc_h2_txt_03.png" alt="公的な奨学金制度と教育ローン" class="onlyPC"><img src="/new/img/admission/scholarship/sp_h2_txt_03.png" alt="公的な奨学金制度と教育ローン" class="onlySP"></h2>
        </div>
        <div class="inner admission_B">
            <h3>公的な奨学金制度</h3>
            <div class="cont_bs03 cf">
                <div class="ship_block05">
                    <h4>高等教育の修学支援新制度</h4>
                    <p>本校は高等教育の修学支援新制度の対象校です。<br>高等教育の修学支援新制度とは、授業料等減免や給付型奨学金の支援が受けられるものです。<br>詳しくは在学高等学校にてお聞きください。</p>
                </div>
                <div class="ship_block05">
                    <h4>独立行政法人日本学生支援機構奨学金制度</h4>
                    <p>人物および成績に優れ経済的理由により、著しく修業に困難がある方に対して、希望者の中から選考の上、独立行政法人日本学生支援機構より奨学金が貸与されます。申込時期、申請方法、申請基準など詳細は、入学後説明会を実施します。高校在学中に申請する予約制度が便利です。詳しくは在学高等学校にてお聞きください。</p>
                </div>
                <div class="ship_block06">
                    <p>参考（2019年度実績）</p>
                    <table class="sp_bdnone">
                        <tbody>
                            <tr>
                                <th>無利子</th>
                                <td class="bld">自宅通学者 月額20,000円、30,000円、40,000円、または53,000円<br>
                                自宅外通学者 月額20,000円、30,000円、40,000円、50,000円、53,000円、または60,000円</td>
                            </tr>
                            <tr>
                                <th>有利子</th>
                                <td class="bld">月額貸与 20,000円～120,000円（10,000円刻み）から選択 </td>
                            </tr>
                            <tr>
                                <th>給付</th>
                                <td class="bld">月額 12,800円～75,800円（世帯所得の区分による）</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <p>詳しくは、日本学生支援機構ホームページをご覧ください。</p>
                <div class="ship_link"><a href="http://www.jasso.go.jp/" target="_blank">日本学生支援機構ホームページ</a></div>
                <div class="ship_block05">
                    <h4>自治体奨学金</h4>
                    <p>人物および成績に優れ経済的理由により、著しく修業に困難がある方に対して、各自治体が希望者の中から選考の上、奨学金を無利子で貸与します。申込時期、申請方法、申請基準など詳細は各自治体（都道府県）事務局までお問い合わせください。</p>
                    <h4>東京都育英資金制度</h4>
                    <p>都内に居住している方の子弟で、選考により月額53,000円（2019年度実績）を貸与。新学期開始後、本校事務局で募集説明をいたします。</p>
                </div>
            </div>
            <h3>教育ローン</h3>
            <div class="cont_bs03 cf">
                <div class="ship_block05">
                    <h4>国の教育ローン - 日本政策金融公庫</h4>
                    <p>本校の新入生や在校生の方は、「国の教育ローン」を利用することができます。 この制度は教育資金を融資する公的な制度で、融資金額は学生一人につき350万円以内、返済期間は15年以内、利率は2019年11月1日現在で年1.66% です。<br>詳しくは日本政策金融公庫教育ローンコールセンター（ハローコール 0570-008656）または最寄りの日本政策金融公庫各支店までお問い合わせください。</p>
                    <div class="ship_link"><a href="https://www.jfc.go.jp/n/finance/search/ippan.html" target="_blank">日本政策金融公庫 国民生活事業 <br class="onlySP">「国の教育ローン」</a></div>
                    <p class="ship_call">教育ローンコールセンター　<br class="onlySP"><em>TEL：0570-00-8656</em>（ナビダイヤル）<br>※上記番号が利用できない場合はこちらへおかけください <br class="onlySP">03-5321-8656</p>
                    <h4>銀行の教育ローン</h4>
                    <p>都市銀行・地方銀行の教育ローンを利用することができます。<br>詳しくは最寄りの銀行窓口に直接お問い合わせください。</p>
                    <h4>学校提携ローン</h4>
                    <p>本校に入学または、在学するご子息を有する保護者の方が利用できる原則連帯保証人不要の教育ローンです。<br>詳細は各専用窓口にお問い合わせください。</p>
                </div>
                <div class="logo_img_01"><img src="/new/img/admission/scholarship/logo_img_01.png" alt="Orico"></div>
                <h4 class="l_h4"> ㈱オリエントコーポレーション　<br class="onlySP">学費サポートプラン</h4>
                <p class="bld">お申し込み・詳細確認・ご返済額シミュレーションなど</p>
                <div class="cf">
                    <div class="ship_link01"><a href="http://www.orico.tv/gakuhi/index.php?clientid=13750633" target="_blank">「東京工学院専門学校」はこちらから</a></div>
                    <div class="ship_link02"><a href="http://www.orico.tv/gakuhi/index.php?clientid=13750641" target="_blank">「東京エアトラベル・ホテル専門学校」は<br class="onlySP">こちらから</a></div>
                </div>
                <div class="ship_block06">
                    <table class="sp_bdnone">
                        <tbody>
                            <tr>
                                <th>ご利用いただける方</th>
                                <td>東京工学院専門学校または東京エアトラベル・ホテル専門学校に入学又は在学する学生の親権者</td>
                            </tr>
                            <tr>
                                <th>ご利用いただける費用</th>
                                <td>入学金・授業料・研修費などの学校納付金</td>
                            </tr>
                            <tr>
                                <th>ご利用の金額</th>
                                <td>10万円以上500万以下</td>
                            </tr>
                            <tr>
                                <th>入金方法</th>
                                <td>オリコから直接東京工学院専門学校または東京エアトラベル・ホテル専門学校へ入金</td>
                            </tr>
                            <tr>
                                <th>お問い合わせ先</th>
                                <td>株式会社オリエントコーポレーション 学費サポートデスク　<br class="onlySP"><em>TEL：0120-517-325</em><br class="onlySP">（受付時間 平日 9：30～17：30）</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="logo_img_02"><img src="/new/img/admission/scholarship/logo_img_02.png" alt="セディナ"></div>
                <h4 class="l_h4"> ㈱セディナ　セディナ学費ローン</h4>
                <p class="bld">お申し込み・詳細確認・ご返済額シミュレーションなど</p>
                <div class="cf">
                    <div class="ship_link01"><a href="https://c-web.cedyna.co.jp/customer/action/ssAA01/WAA0102Action/RWAA010207?kam_id=614909&torihiki_id=6Z" target="_blank">「東京工学院専門学校」はこちらから</a></div>
                    <div class="ship_link02"><a href="https://c-web.cedyna.co.jp/customer/action/ssAA01/WAA0102Action/RWAA010207?kam_id=614910&torihiki_id=6Z" target="_blank">「東京エアトラベル・ホテル専門学校」は<br class="onlySP">こちらから</a></div>
                </div>
                <div class="ship_block06">
                    <table class="sp_bdnone">
                        <tbody>
                            <tr>
                                <th>ご利用いただける方</th>
                                <td>東京工学院専門学校または東京エアトラベル・ホテル専門学校にご入学または在学されている学生の保護者さまで安定した収入のある方。または学生本人（有職者に限ります）</td>
                            </tr>
                            <tr>
                                <th>ご利用いただける費用</th>
                                <td>入学金・授業料・教材費など、学校へ納付する学納金<br>※学校以外へ納付する費用はご利用いただけません（定期代・生活費など）</td>
                            </tr>
                            <tr>
                                <th>ご利用の金額</th>
                                <td>原則、4万円以上500万円以下<br>
                                    ※納入期ごと（半期または通期）のご利用となります。<br>
                                    ※複数年度分学費をまとめての利用はできません。<br>
                                    ※学費納付書、学費振込依頼書、募集要項などに記載された金額が対象</td>
                            </tr>
                            <tr>
                                <th>入金方法</th>
                                <td>学校指定の口座へセディナが直接お振り込みします。<br>※お申込者さまのお口座へのお振り込みはございません。</td>
                            </tr>
                            <tr>
                                <th>お問い合わせ先</th>
                                <td>株式会社セディナ カスタマーセンター　<br class="onlySP"><em>TEL：0120-686-909</em><br class="onlySP">（受付時間 平日 9：30～17：00）</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="logo_img_03"><img src="/new/img/admission/scholarship/logo_img_03.png" alt="JACCS"></div>
                <h4 class="l_h4"> ㈱ジャックス　悠裕プラン</h4>
                <p class="bld">お申し込み・詳細確認・ご返済額シミュレーションなど</p>
                <div class="logo_img_04"><a href="http://www.jaccs.co.jp/service/credit/education/yuyu/" target="_blank"><img src="/new/img/admission/scholarship/banner_img_01.png" alt="教育ローン"></a></div>
                <div class="ship_block06">
                    <table class="sp_bdnone">
                        <tbody>
                            <tr>
                                <th>ご利用いただける方</th>
                                <td>東京工学院専門学校または東京エアトラベル・ホテル専門学校に入学予定または在学する学生の親権者かつ安定収入のある方</td>
                            </tr>
                            <tr>
                                <th>ご利用いただける費用</th>
                                <td>入学金、授業料、施設設備費、教材費などの学費納付金</td>
                            </tr>
                            <tr>
                                <th>ご利用の金額</th>
                                <td>学校が発行する学費納付金明細書など（振込依頼書）に記載されている金額を上限とします。</td>
                            </tr>
                            <tr>
                                <th>入金方法</th>
                                <td>ジャックスが学校へ立替払いをします。</td>
                            </tr>
                            <tr>
                                <th>お問い合わせ先</th>
                                <td>株式会社ジャックス コンシュマーデスク<br><em>TEL：0120-338-817</em><br class="onlySP">（受付時間 平日・土日祝日 10：00～19：00）</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <a class="webEntryBnr" href="/admission/webentry.php"><img src="/new/img/admission/webentry/bnr_webentry.jpg" alt="WEB AOエントリー、WEB出願"></a>

        </div>
        <div class="admission_block03 cf">
            <div class="admission_block03_list match">
                <div class="admission_block03_ttl01">
                    <h3>入学方法</h3>
                </div>
                <ul>
                    <li><a href="/admission/admission.php">入学までの流れ</a></li>
                    <li><a href="/admission/selection.php">各種選考方法（推薦・一般・AO）</a></li>
                    <li><a href="/admission/ao.php">AO入学とは?</a></li>
                </ul>
            </div>
            <div class="admission_block03_list match">
                <div class="admission_block03_ttl02">
                    <h3>学　費</h3>
                </div>
                <ul>
                    <li><a href="/admission/tuition.php">東京工学院専門学校 学費一覧</a></li>
                    <li><a href="/admission/tuitionair.php">東京エアトラベル・ホテル専門学校 学費一覧</a></li>
                </ul>
            </div>
            <div class="admission_block03_list match">
                <div class="admission_block03_ttl03">
                    <h3>各種奨学金制度</h3>
                </div>
                <ul>
                    <li><a href="/admission/tokutaisei.php">特待生制度</a></li>
                    <li><a href="/admission/scholarship.php">各種奨学金制度</a></li>
                    <li><a href="/admission/scholarship.php#unker02">本校独自の奨学金制度</a></li>
                    <li><a href="/admission/scholarship.php#unker03">公的な奨学金制度と教育ローン</a></li>
                </ul>
            </div>
            <div class="admission_block03_list match">
                <div class="admission_block03_ttl04">
                    <h3>学校生活</h3>
                </div>
                <ul>
                    <li><a href="/admission/apartment.php">学生寮・マンション</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
-->
   <!--/footer-->
    <footer>
    	<div class="inner">
            <p>お電話でのご相談や資料請求・来校のご予約はこちらまで</p>
            <div class="cf">
                <dl>
                    <dt>東京工学院専門学校</dt>
                    <dd><img src="/new/img/kogyo_tel.png" alt="0120-634-200"></dd>
                </dl>
                <dl>
                    <dt>東京エアトラベル・ホテル専門学校</dt>
                    <dd><img src="/new/img/air_tel.png" alt="0120-634-300"></dd>
                </dl>
            </div>

            <div class="add cf">
                <div class="logo">
                <a href="/"><img src="/new/img/logo.svg" alt="総合学院テクノスカレッジ"></a>
                    <p>総合学院テクノスカレッジ</p>
                </div>
                <div class="add_box">
                    <p>府中・小金井インテリジェントキャンパス ： <br class="onlySP">〒184-8543 東京都小金井市前原町5-1-29</p>
                    <p>渋谷サテライトキャンパス ： <br class="onlySP">〒151-0051 東京都渋谷区千駄ケ谷5-30-16</p>
                </div>
                    
                <div class="footerMenu">
                    <a href="/privacypolicy.php">プライバシーポリシー</a>
                </div>
            
            </div>

            <p class="copyright">Copyright © Technos College. All Rights Reserved.</p>
        </div>

        <p id="gotop"><img src="/new/img/gotop.png" alt="gotop"></p>
    </footer>
    <!--footer/-->


</div><!--wrapper/-->

<script type="text/javascript" class="microad_blade_track">
<!--
var microad_blade_jp = microad_blade_jp || { 'params' : new Array(), 'complete_map' : new Object() };
(function() {
var param = {'co_account_id' : '24', 'group_id' : '', 'country_id' : '1', 'ver' : '2.1.0'};

var param_custom =
{
"set_1": {
"item" : "rsnemibl20160805079",
}
}
param.custom = param_custom;

microad_blade_jp.params.push(param);

var src = (location.protocol == 'https:')
? 'https://d-track.send.microad.jp/js/blade_track_jp.js' : 'http://d-cache.microad.jp/js/blade_track_jp.js';

var bs = document.createElement('script');
bs.type = 'text/javascript'; bs.async = true;
bs.charset = 'utf-8'; bs.src = src;

var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(bs, s);
})();
-->
</script>

<!-- add. 0909 recruit -->
<script type="text/javascript" class="microad_blade_track">
<!--
var microad_blade_jp = microad_blade_jp || { 'params' : new Array(), 'complete_map' : new Object() };
(function() {
var param = {'co_account_id' : '24', 'group_id' : '', 'country_id' : '1', 'ver' : '2.1.0'};
microad_blade_jp.params.push(param);

var src = (location.protocol == 'https:')
? 'https://d-track.send.microad.jp/js/blade_track_jp.js' : 'http://d-cache.microad.jp/js/blade_track_jp.js';

var bs = document.createElement('script');
bs.type = 'text/javascript'; bs.async = true;
bs.charset = 'utf-8'; bs.src = src;

var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(bs, s);
})();
-->
</script>


</body>
</html>


<!--   学生寮・マンション   -->
